/**
 * 内容脚本
 * 负责创建侧边栏UI和处理与页面的交互
 */

// 全局变量
let sidebarContainer = null;
let interceptedData = [];
let analysisReportUrl = null; // 存储分析报告的下载链接
let currentUrl = window.location.href;
// URL监听相关变量已整合到initializeUrlMonitoring函数内部

/**
 * 日志工具函数
 */
function logInfo(message, data = null) {
  console.log(`[聚抖自媒体大师] ${message}`, data || '');
}

function logError(message, error = null) {
  console.error(`[聚抖自媒体大师] ${message}`, error || '');
}

/**
 * 检查是否是目标页面
 */
function isTargetPage() {
  const url = window.location.href;
  return url.includes('douyin.com/user') || url.includes('douyin.com/video');
}

/**
 * 初始化URL监听器 - 高效定时器方案
 */
function initializeUrlMonitoring() {
  let lastUrl = window.location.href;
  let isChecking = false; // 防止重复检查

  // 智能定时器：根据页面活跃度调整检查频率
  const smartUrlCheck = () => {
    if (isChecking) return; // 防止重复执行

    isChecking = true;
    const currentUrl = window.location.href;

    // 只在URL真正变化时才处理
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      handleUrlChange();
    }

    isChecking = false;
  };

  // 使用高效的定时器：页面可见时500ms检查一次，隐藏时2秒检查一次
  const startMonitoring = () => {
    if (window.urlMonitorInterval) clearInterval(window.urlMonitorInterval);

    // 根据页面可见性调整检查频率
    const interval = document.hidden ? 5000 : 2000;
    window.urlMonitorInterval = setInterval(smartUrlCheck, interval);
  };

  // 监听页面可见性变化，动态调整检查频率
  document.addEventListener('visibilitychange', startMonitoring);

  // 监听浏览器前进后退（这个很重要，需要保留）
  window.addEventListener('popstate', () => {
    setTimeout(smartUrlCheck, 100); // 延迟确保DOM更新完成
  });

  // 启动监听
  startMonitoring();

  logInfo('URL监听器已初始化（高效定时器方案）');
}

/**
 * 处理URL变化
 */
function handleUrlChange() {
  const newUrl = window.location.href;

  if (newUrl !== currentUrl) {
    const oldPageType = detectPageType(currentUrl);
    const newPageType = detectPageType(newUrl);

    logInfo('检测到URL变化:', {
      from: currentUrl,
      to: newUrl,
      pageChange: `${oldPageType} → ${newPageType}`
    });

    currentUrl = newUrl;

    // 更新侧边栏内容
    if (sidebarContainer) {
      updateSidebarContent();
    }

    // 如果不再是目标页面，隐藏侧边栏
    if (!isTargetPage()) {
      if (sidebarContainer) {
        sidebarContainer.style.display = 'none';
        logInfo('隐藏侧边栏：不是目标页面');
      }
    } else {
      // 如果是目标页面但侧边栏不存在，创建它
      if (!sidebarContainer) {
        createSidebarContainer();
      } else {
        sidebarContainer.style.display = 'flex';
        logInfo('显示侧边栏：目标页面');
      }
    }
  }
}

/**
 * 清理URL监听器
 */
function cleanupUrlMonitoring() {
  // 清理定时器（如果存在）
  if (window.urlMonitorInterval) {
    clearInterval(window.urlMonitorInterval);
    window.urlMonitorInterval = null;
  }

  logInfo('URL监听器已清理');
}

/**
 * 动态加载 Material Icons 字体
 * 绕过 CSP 限制的解决方案
 */
function loadMaterialIcons() {
  // 检查是否已经加载过
  if (document.getElementById('material-icons-font')) {
    return;
  }

  // 创建 link 元素加载 Material Icons
  const materialIconsLink = document.createElement('link');
  materialIconsLink.id = 'material-icons-font';
  materialIconsLink.rel = 'stylesheet';
  materialIconsLink.href = 'https://fonts.googleapis.com/icon?family=Material+Icons';

  // 创建 Noto Sans SC 字体链接
  const notoSansLink = document.createElement('link');
  notoSansLink.id = 'noto-sans-font';
  notoSansLink.rel = 'stylesheet';
  notoSansLink.href = 'https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;500;700&display=swap';

  // 监听加载事件
  materialIconsLink.onload = () => {
    logInfo('Material Icons 字体加载成功');
  };

  materialIconsLink.onerror = () => {
    logError('Material Icons 字体加载失败，将使用备用方案');
    // 如果加载失败，添加备用CSS
    addFallbackIconStyles();
  };

  // 添加到 head
  document.head.appendChild(materialIconsLink);
  document.head.appendChild(notoSansLink);

  logInfo('正在尝试加载 Material Icons 字体...');
}

/**
 * 添加备用图标样式
 * 当 Material Icons 无法加载时使用
 */
function addFallbackIconStyles() {
  const fallbackStyle = document.createElement('style');
  fallbackStyle.id = 'material-icons-fallback';
  fallbackStyle.textContent = `
    /* Material Icons 备用方案 */
    .material-icons {
      font-family: Arial, sans-serif !important;
      font-style: normal !important;
      font-weight: normal !important;
      display: inline-block !important;
      line-height: 1 !important;
      text-transform: none !important;
      letter-spacing: normal !important;
      word-wrap: normal !important;
      white-space: nowrap !important;
      direction: ltr !important;
      -webkit-font-smoothing: antialiased !important;
      text-rendering: optimizeLegibility !important;
      -moz-osx-font-smoothing: grayscale !important;
    }
    
    /* 使用 Unicode 字符替代图标 */
    .material-icons[data-icon="analytics"]:before { content: "📊"; }
    .material-icons[data-icon="unfold_less"]:before { content: "⬅"; }
    .material-icons[data-icon="close"]:before { content: "✕"; }
    .material-icons[data-icon="link"]:before { content: "🔗"; }
    .material-icons[data-icon="assessment"]:before { content: "📈"; }
    .material-icons[data-icon="build"]:before { content: "🔧"; }
    .material-icons[data-icon="text_snippet"]:before { content: "📝"; }
    .material-icons[data-icon="playlist_add_check"]:before { content: "📋"; }
    .material-icons[data-icon="insights"]:before { content: "💡"; }
    .material-icons[data-icon="clear_all"]:before { content: "🗑"; }
    .material-icons[data-icon="list"]:before { content: "📄"; }
    .material-icons[data-icon="assignment"]:before { content: "📊"; }
    .material-icons[data-icon="info"]:before { content: "ℹ"; }
  `;
  document.head.appendChild(fallbackStyle);
  logInfo('已添加 Material Icons 备用样式');
}

/**
 * 创建侧边栏容器
 */
function createSidebarContainer() {
  if (sidebarContainer) return;

  // 先加载 Material Icons 字体
  loadMaterialIcons();

  // 加载侧边栏HTML内容（样式已内嵌在HTML中）
  fetch(chrome.runtime.getURL('sidebar.html'))
    .then(response => response.text())
    .then(html => {
      // 创建临时容器来解析HTML
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = html;

      // 提取style标签并添加到head
      const styleElement = tempDiv.querySelector('style');
      if (styleElement) {
        // 为了提高CSS优先级，给所有选择器添加更高的特异性
        let cssText = styleElement.textContent;

        // 增加CSS选择器特异性并添加!important
        // 将所有选择器替换为更高特异性的版本
        cssText = cssText.replace(/#douyin-analyzer-sidebar/g, 'html body #douyin-analyzer-sidebar');
        cssText = cssText.replace(/\.sidebar-/g, 'html body #douyin-analyzer-sidebar .sidebar-');
        cssText = cssText.replace(/\.section/g, 'html body #douyin-analyzer-sidebar .section');
        cssText = cssText.replace(/\.function-/g, 'html body #douyin-analyzer-sidebar .function-');
        cssText = cssText.replace(/\.stats-/g, 'html body #douyin-analyzer-sidebar .stats-');
        cssText = cssText.replace(/\.data-/g, 'html body #douyin-analyzer-sidebar .data-');
        cssText = cssText.replace(/\.result-/g, 'html body #douyin-analyzer-sidebar .result-');
        cssText = cssText.replace(/\.no-/g, 'html body #douyin-analyzer-sidebar .no-');
        cssText = cssText.replace(/\.current-/g, 'html body #douyin-analyzer-sidebar .current-');
        cssText = cssText.replace(/\.loading-/g, 'html body #douyin-analyzer-sidebar .loading-');
        cssText = cssText.replace(/\.icon/g, 'html body #douyin-analyzer-sidebar .icon');

        // 添加!important来确保样式优先级
        cssText = cssText.replace(/;/g, ' !important;');
        cssText = cssText.replace(/!important !important/g, '!important');

        const newStyle = document.createElement('style');
        newStyle.id = 'douyin-sidebar-styles';
        newStyle.textContent = cssText;
        document.head.appendChild(newStyle);

        logInfo('CSS样式已强制插入到head中');
        logInfo('处理后的CSS长度:', cssText.length);

        // 调试：输出部分CSS内容
        console.log('CSS样式预览:', cssText.substring(0, 500) + '...');

        // 添加额外的强制样式重置
        const forceStyles = `
        html body #douyin-analyzer-sidebar.douyin-sidebar-hidden {
          display: none !important;
          visibility: hidden !important;
          opacity: 0 !important;
          transform: translateX(100%) !important;
          pointer-events: none !important;
          z-index: -9999 !important;
        }
        
        html body #douyin-analyzer-sidebar {
          all: initial !important;
          position: fixed !important;
          top: 0 !important;
          right: 0 !important;
          width: 360px !important;
          height: 100vh !important;
          background: #ffffff !important;
          border-left: 1px solid #e5e5e7 !important;
          box-shadow: 0 0 20px rgba(0, 0, 0, 0.08) !important;
          z-index: 999999 !important;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
          font-size: 14px !important;
          color: #1d1d1f !important;
          display: flex !important;
          flex-direction: column !important;
          overflow: hidden !important;
        }
        `;

        const forceStyle = document.createElement('style');
        forceStyle.id = 'douyin-sidebar-force-styles';
        forceStyle.textContent = forceStyles;
        document.head.appendChild(forceStyle);
      }

      // 创建主容器并设置内容（去掉style标签）
      sidebarContainer = document.createElement('div');

      // 直接设置HTML内容，去掉style部分
      const contentHtml = html.replace(/<style[\s\S]*?<\/style>/, '');
      sidebarContainer.innerHTML = contentHtml;

      // 确保容器有正确的ID和样式
      sidebarContainer.id = 'douyin-analyzer-sidebar';

      document.body.appendChild(sidebarContainer);
      logInfo('侧边栏已创建，强制样式已应用');
      initializeSidebar();
    })
    .catch(error => {
      logError('加载侧边栏失败:', error);
    });
}

/**
 * 初始化侧边栏功能
 */
function initializeSidebar() {
  logInfo('初始化侧边栏');

  // 添加事件监听器
  setupSidebarEventListeners();

  // 设置默认状态
  updateSidebarContent();

  // 拦截器监听已在 initializeContentScript 中设置，这里不需要重复设置
}

/**
 * 设置侧边栏事件监听器
 */
function setupSidebarEventListeners() {
  const sidebar = document.getElementById('douyin-analyzer-sidebar');
  if (!sidebar) return;

  // 关闭按钮
  const closeBtn = sidebar.querySelector('.sidebar-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      logInfo('关闭按钮被点击');
      closeSidebar();
    });
    logInfo('关闭按钮事件监听器已设置');
  } else {
    logError('未找到关闭按钮元素');
  }

  // 功能按钮事件
  const extractAllBtn = sidebar.querySelector('.extract-all-text');
  if (extractAllBtn) {
    extractAllBtn.addEventListener('click', extractAllTexts);
  }

  const clearBtn = sidebar.querySelector('.clear-data');
  if (clearBtn) {
    clearBtn.addEventListener('click', clearInterceptedData);
  }

  // 页面操作按钮事件
  const pageActionBtn = sidebar.querySelector('.page-action-btn');
  if (pageActionBtn) {
    pageActionBtn.addEventListener('click', handlePageAction);
  }

  // 下载视频按钮事件
  const downloadVideoBtn = sidebar.querySelector('.download-video-btn');
  if (downloadVideoBtn) {
    downloadVideoBtn.addEventListener('click', () => {
      const url = downloadVideoBtn.getAttribute('data-video-url');
      if (url) {
        handleDownloadVideo(url);
      }
    });
  }

  // 下载报告按钮事件
  const downloadReportBtn = sidebar.querySelector('.download-report-btn');
  if (downloadReportBtn) {
    downloadReportBtn.addEventListener('click', () => {
      if (analysisReportUrl) {
        handleDownloadReport(analysisReportUrl);
      }
    });
  }

  // 取消提取按钮事件
  const cancelExtractBtn = sidebar.querySelector('.cancel-extract-btn');
  if (cancelExtractBtn) {
    cancelExtractBtn.addEventListener('click', () => {
      if (currentExtractOperation) {
        currentExtractOperation.cancel();
      }
    });
  }
}

/**
 * 设置拦截器监听器
 */
function setupInterceptorListener() {
  // 监听来自注入脚本的消息
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;

    if (event.data && event.data.type === 'DOUYIN_API_DATA') {
      handleInterceptedData(event.data);
    }
  });

  // 拦截脚本已在initializeContentScript中注入，这里不需要重复注入
}

/**
 * 注入拦截器脚本
 */
function injectInterceptorScript() {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('inject.js');
  script.onload = function () {
    logInfo('拦截器脚本已注入');
    this.remove();
  };
  (document.head || document.documentElement).appendChild(script);
}

/**
 * 提取抖音视频数据的处理函数
 */
function extractDouyinVideoData(response) {
  if (!response) return [];

  const awemeList = Array.isArray(response.aweme_list) ? response.aweme_list : [];
  if (awemeList.length === 0) return [];

  return awemeList.map(aweme => {
    if (!aweme || !aweme.aweme_id) return null;

    const title = aweme?.desc || aweme?.raw_title || '';
    const nickname = aweme?.author?.nickname || '';
    const avatar = aweme?.author?.avatar_large?.url_list?.[0] ||
      aweme?.author?.avatar_thumb?.url_list?.[0] ||
      aweme?.author?.avatar_medium?.url_list?.[0] || '';
    const cover = aweme?.video?.cover?.url_list?.[0] ||
      aweme?.video?.origin_cover?.url_list?.[0] ||
      aweme?.video?.dynamic_cover?.url_list?.[0] || '';

    const statistics = aweme?.statistics || {};
    const diggCount = statistics?.digg_count ?? 0;
    const shareCount = statistics?.share_count ?? 0;
    const commentCount = statistics?.comment_count ?? 0;
    const collectCount = statistics?.collect_count ?? 0;

    const downList = aweme?.video?.download_addr?.url_list || [];
    const playList = aweme?.video?.play_addr?.url_list || [];
    let videoUrl = '';

    if (Array.isArray(downList) && downList.length > 0) {
      videoUrl = downList.find(Boolean) || '';
    } else if (Array.isArray(playList) && playList.length > 0) {
      videoUrl = playList.find(Boolean) || '';
    } else if (aweme?.video?.play_addr?.uri) {
      const vid = aweme.video.play_addr.uri;
      videoUrl = `https://aweme.snssdk.com/aweme/v1/download/?video_id=${vid}&ratio=720p&line=0`;
    }

    const musicUrl = aweme?.music?.play_url?.url_list?.[0] ||
      aweme?.music?.audio?.url_list?.[0] || '';
    const duration = aweme?.music?.duration || aweme?.duration || 0;

    return {
      awemeId: aweme.aweme_id,
      title,
      nickname,
      avatar,
      cover,
      diggCount,
      shareCount,
      commentCount,
      collectCount,
      videoUrl,
      musicUrl,
      duration,
      createTime: aweme?.create_time,
      timestamp: Date.now()
    };
  }).filter(item => item !== null);
}

/**
 * 从HTML页面解析用户数据
 */
function parseUserDataFromHTML() {
  try {
    const userInfo = {};
    
    // 解析用户昵称
    const nicknameElement = document.querySelector('[data-e2e="user-info"] h1, .GMEdHsXq span span span span span span');
    if (nicknameElement) {
      userInfo.nickname = nicknameElement.textContent.trim();
    }
    
    // 解析关注数
    const followingElement = document.querySelector('[data-e2e="user-info-follow"] .C1cxu0Vq');
    if (followingElement) {
      userInfo.following_count = parseNumberString(followingElement.textContent.trim());
    }
    
    // 解析粉丝数
    const fansElement = document.querySelector('[data-e2e="user-info-fans"] .C1cxu0Vq');
    if (fansElement) {
      userInfo.follower_count = parseNumberString(fansElement.textContent.trim());
    }
    
    // 解析获赞数
    const likeElement = document.querySelector('[data-e2e="user-info-like"] .C1cxu0Vq');
    if (likeElement) {
      userInfo.total_favorited = parseNumberString(likeElement.textContent.trim());
    }
    
    // 解析年龄（可选）
    const ageElement = document.querySelector('.YcpSmZeQ span');
    if (ageElement && ageElement.textContent.includes('岁')) {
      const ageText = ageElement.textContent.match(/(\d+)岁/);
      if (ageText) {
        userInfo.user_age = parseInt(ageText[1]);
      }
    }
    
    logInfo('从HTML解析的用户数据:', userInfo);
    return userInfo;
  } catch (error) {
    logError('解析HTML用户数据失败:', error);
    return {};
  }
}

/**
 * 解析数字字符串（处理万、k等单位）
 */
function parseNumberString(str) {
  if (!str) return 0;
  
  const num = parseFloat(str);
  if (isNaN(num)) return 0;
  
  if (str.includes('万')) {
    return Math.floor(num * 10000);
  } else if (str.includes('k') || str.includes('K')) {
    return Math.floor(num * 1000);
  } else {
    return Math.floor(num);
  }
}


/**
 * 处理拦截到的数据
 */
function handleInterceptedData(data) {
  logInfo('收到拦截数据:', data.apiName);

  // 只处理视频数据，不再拦截主页信息
  if (data.apiName === '博主首页视频接口') {
    // 处理视频数据
    const processedVideos = extractDouyinVideoData(data.response);

    if (processedVideos.length > 0) {
      // 将处理后的数据添加到显示列表
      interceptedData.push(...processedVideos);

      // 立即更新sidebar显示
      updateInterceptedDataDisplay();

      logInfo(`已处理 ${processedVideos.length} 个视频，当前总数: ${interceptedData.length}`);
    }
  }

  // 不再发送给background.js保存（删除了chrome.runtime.sendMessage调用）
}

/**
 * 更新拦截数据显示 - 显示视频列表
 */
function updateInterceptedDataDisplay() {
  const dataList = document.querySelector('.intercepted-data-list');
  if (!dataList) return;

  // 如果没有数据，显示空状态
  if (interceptedData.length === 0) {
    dataList.innerHTML = `
      <div class="no-data-message">
        <span class="material-icons">video_library</span>
        <span>暂无视频数据，请访问抖音用户主页</span>
      </div>
    `;
    return;
  }

  // 清空现有内容
  dataList.innerHTML = '';

  // 显示视频列表
  interceptedData.forEach((video, index) => {
    const videoItem = document.createElement('div');
    videoItem.className = 'video-item';

    // 格式化数字显示
    const formatCount = (count) => {
      if (count >= 10000) return `${(count / 10000).toFixed(1)}w`;
      if (count >= 1000) return `${(count / 1000).toFixed(1)}k`;
      return count.toString();
    };

    // 格式化时长
    const formatDuration = (duration) => {
      if (!duration) return '--';
      const minutes = Math.floor(duration / 60000);
      const seconds = Math.floor((duration % 60000) / 1000);
      return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    };

    videoItem.innerHTML = `
      <div class="video-cover">
        <img src="${video.cover}" alt="视频封面" onerror="this.src='data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"60\" height=\"60\"><rect width=\"60\" height=\"60\" fill=\"%23f0f0f0\"/><text x=\"30\" y=\"35\" text-anchor=\"middle\" fill=\"%23999\">封面</text></svg>'">
        <div class="video-duration">${formatDuration(video.duration)}</div>
      </div>
      <div class="video-info">
        <div class="video-title">${video.title || '无标题'}</div>
        <div class="video-author">
          <img src="${video.avatar}" alt="头像" class="author-avatar" onerror="this.style.display='none'">
          <span class="author-name">${video.nickname}</span>
        </div>
        <div class="video-stats">
          <span class="stat-item">
            <span class="material-icons">favorite</span>
            ${formatCount(video.diggCount)}
          </span>
          <span class="stat-item">
            <span class="material-icons">comment</span>
            ${formatCount(video.commentCount)}
          </span>
          <span class="stat-item">
            <span class="material-icons">share</span>
            ${formatCount(video.shareCount)}
          </span>
        </div>
      </div>
      <div class="video-actions">
        <button class="action-btn download-btn" data-video-url="${video.videoUrl}" title="下载视频">
          <span class="material-icons">download</span>
        </button>
      </div>
    `;

    dataList.appendChild(videoItem);
  });

  // 绑定按钮事件
  bindVideoItemEvents();

  // 更新统计信息
  updateStatsDisplay();
}

/**
 * 绑定视频项目事件
 */
function bindVideoItemEvents() {
  // 下载视频按钮
  document.querySelectorAll('.download-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const videoUrl = btn.getAttribute('data-video-url');
      if (videoUrl) {
        window.open(videoUrl, '_blank');
        showSuccess('已在新标签页打开视频，可右键保存');
      } else {
        showError('视频链接不可用');
      }
    });
  });
}

/**
 * 更新视频数量显示
 */
function updateStatsDisplay() {
  const videoCountNumber = document.querySelector('.video-count-number');
  if (videoCountNumber) {
    videoCountNumber.textContent = interceptedData.length;
  }

  // 更新其他统计信息
  const statsElement = document.querySelector('.data-stats');
  if (statsElement) {
    const totalVideos = interceptedData.length;
    const totalLikes = interceptedData.reduce((sum, video) => sum + (video.diggCount || 0), 0);
    const avgLikes = totalVideos > 0 ? Math.round(totalLikes / totalVideos) : 0;

    statsElement.innerHTML = `
      <div class="stat-item">
        <span class="stat-label">视频总数:</span>
        <span class="stat-value">${totalVideos}</span>
      </div>
      <div class="stat-item">
        <span class="stat-label">平均点赞:</span>
        <span class="stat-value">${avgLikes.toLocaleString()}</span>
      </div>
    `;
  }
}

/**
 * 更新侧边栏内容
 */
function updateSidebarContent() {
  const currentUrl = window.location.href;
  const urlDisplay = document.querySelector('.current-url');
  if (urlDisplay) {
    urlDisplay.textContent = currentUrl;
  }

  // 更新智能按钮
  updatePageActionButton(currentUrl);
}

/**
 * 检测页面类型
 */
function detectPageType(url) {
  // 视频详情页：包含 modal_id 参数
  if (url.includes('modal_id=')) {
    return 'video';
  }

  // 用户主页：/user/ 路径但不包含 modal_id
  if (url.includes('/user/') && !url.includes('modal_id=')) {
    return 'profile';
  }

  return 'unknown';
}

/**
 * 更新页面操作按钮
 */
function updatePageActionButton(url) {
  const pageActionBtn = document.querySelector('.page-action-btn');
  if (!pageActionBtn) return;

  const pageType = detectPageType(url);
  const iconElement = pageActionBtn.querySelector('.material-icons');
  const textElement = pageActionBtn.querySelector('.btn-text');

  // 获取下载视频按钮
  const downloadVideoBtn = document.querySelector('.download-video-btn');

  switch (pageType) {
    case 'video':
      iconElement.textContent = 'text_snippet';
      textElement.textContent = '提取文案';
      pageActionBtn.setAttribute('data-action', 'extract-text');
      
      // 显示下载视频按钮并设置URL
      if (downloadVideoBtn) {
        downloadVideoBtn.classList.remove('hidden');
        downloadVideoBtn.setAttribute('data-video-url', url);
      }
      
      // 隐藏下载报告按钮
      hideDownloadReportButton();
      
      logInfo('检测到视频页面，按钮切换为：提取文案 + 下载视频');
      break;

    case 'profile':
      iconElement.textContent = 'insights';
      textElement.textContent = '分析主页';
      pageActionBtn.setAttribute('data-action', 'analyze-profile');
      
      // 启用按钮，不再需要等待API数据加载
      pageActionBtn.disabled = false;
      pageActionBtn.style.opacity = '1';
      
      // 隐藏下载视频按钮和下载报告按钮
      if (downloadVideoBtn) {
        downloadVideoBtn.classList.add('hidden');
      }
      hideDownloadReportButton();
      
      logInfo('检测到用户主页，按钮切换为：分析主页');
      break;

    default:
      iconElement.textContent = 'help';
      textElement.textContent = '页面类型未知';
      pageActionBtn.setAttribute('data-action', 'unknown');
      
      // 隐藏下载视频按钮和下载报告按钮
      if (downloadVideoBtn) {
        downloadVideoBtn.classList.add('hidden');
      }
      hideDownloadReportButton();
      
      logInfo('未知页面类型');
      break;
  }
}

// 下载视频按钮现在是静态的，不需要动态添加/删除函数

/**
 * 处理下载视频
 */
function handleDownloadVideo(url) {
  logInfo('开始下载视频:', url);

  // 从URL中提取modal_id
  const urlParams = new URLSearchParams(new URL(url).search);
  const modalId = urlParams.get('modal_id');
  
  if (!modalId) {
    showError('无法获取视频ID');
    return;
  }

  // 从拦截数据中查找对应的视频信息
  const videoData = interceptedData.find(video => video.awemeId === modalId);
  
  if (!videoData || !videoData.videoUrl) {
    showError('未找到视频数据或下载地址，请先访问用户主页加载视频列表');
    return;
  }

  logInfo('找到视频下载地址:', videoData.videoUrl);

  // 在新标签页打开视频下载地址
  window.open(videoData.videoUrl, '_blank');
  showSuccess('已在新标签页打开视频，可右键保存');
}

/**
 * 处理页面操作按钮点击
 */
function handlePageAction() {
  chrome.runtime.sendMessage({ type: 'GET_USER_AUTH' }, (response) => {
    if (response && response.success && response.data.token) {
      // 用户已登录，继续执行操作
      const pageActionBtn = document.querySelector('.page-action-btn');
      if (!pageActionBtn) return;

      const action = pageActionBtn.getAttribute('data-action');

      switch (action) {
        case 'extract-text':
          extractSingleText();
          break;

        case 'analyze-profile':
          analyzeProfile();
          break;

        default:
          showError('当前页面类型不支持操作');
          break;
      }
    } else {
      // 用户未登录，显示提示弹窗
      showLoginPromptModal();
    }
  });
}

/**
 * 关闭侧边栏
 */
function closeSidebar() {
  logInfo('closeSidebar函数被调用');
  if (!sidebarContainer) {
    logError('sidebarContainer不存在');
    return;
  }

  logInfo('隐藏侧边栏容器');

  // 使用更强的方式隐藏，覆盖所有可能的CSS规则
  sidebarContainer.style.setProperty('display', 'none', 'important');
  sidebarContainer.style.setProperty('visibility', 'hidden', 'important');
  sidebarContainer.style.setProperty('opacity', '0', 'important');
  sidebarContainer.style.setProperty('transform', 'translateX(100%)', 'important');
  sidebarContainer.style.setProperty('pointer-events', 'none', 'important');
  sidebarContainer.style.setProperty('z-index', '-9999', 'important');

  // 额外添加一个隐藏类
  sidebarContainer.classList.add('douyin-sidebar-hidden');

  // 调试：检查元素状态
  logInfo('侧边栏元素ID:', sidebarContainer.id);
  logInfo('侧边栏当前display值:', window.getComputedStyle(sidebarContainer).display);
  logInfo('侧边栏当前visibility值:', window.getComputedStyle(sidebarContainer).visibility);
  logInfo('侧边栏classList:', sidebarContainer.classList.toString());

  // 最终备用方案：如果样式无效，直接从DOM中移除
  setTimeout(() => {
    const computedDisplay = window.getComputedStyle(sidebarContainer).display;
    if (computedDisplay !== 'none') {
      logInfo('样式隐藏失败，使用DOM移除方案');
      sidebarContainer.remove();
      sidebarContainer = null; // 重置引用
    }
  }, 100);

  // 显示圆形重新打开按钮
  logInfo('准备显示重新打开按钮');
  showReopenButton();
  logInfo('侧边栏已关闭，显示重新打开按钮');
}

/**
 * 显示重新打开按钮
 */
function showReopenButton() {
  // 移除已存在的重新打开按钮
  const existingBtn = document.getElementById('douyin-reopen-btn');
  if (existingBtn) {
    existingBtn.remove();
  }

  const reopenBtn = document.createElement('div');
  reopenBtn.id = 'douyin-reopen-btn';
  reopenBtn.innerHTML = `
    <span class="material-icons">analytics</span>
  `;

  reopenBtn.addEventListener('click', () => {
    if (sidebarContainer && document.body.contains(sidebarContainer)) {
      // 侧边栏存在且在DOM中，只需要恢复样式
      sidebarContainer.classList.remove('douyin-sidebar-hidden');

      // 恢复所有样式，使用!important覆盖
      sidebarContainer.style.setProperty('display', 'flex', 'important');
      sidebarContainer.style.setProperty('visibility', 'visible', 'important');
      sidebarContainer.style.setProperty('opacity', '1', 'important');
      sidebarContainer.style.setProperty('transform', 'translateX(0)', 'important');
      sidebarContainer.style.setProperty('pointer-events', 'auto', 'important');
      sidebarContainer.style.setProperty('z-index', '999999', 'important');

      logInfo('侧边栏样式已恢复');
    } else {
      // 侧边栏被移除了，需要重新创建
      logInfo('侧边栏已被移除，重新创建');
      sidebarContainer = null;
      createSidebarContainer();
    }

    // 添加退出动画
    reopenBtn.classList.remove('show');
    setTimeout(() => {
      reopenBtn.remove();
    }, 300);
  });

  document.body.appendChild(reopenBtn);

  // 添加进入动画
  setTimeout(() => {
    reopenBtn.classList.add('show');
  }, 100);
}

// 全局变量用于存储取消操作
let currentExtractOperation = null;

/**
 * 提取单个文案
 */
function extractSingleText() {
  logInfo('开始提取单个文案');

  const currentUrl = window.location.href;
  
  // 从URL中提取modal_id（即aweme_id）
  const urlParams = new URLSearchParams(window.location.search);
  const modalId = urlParams.get('modal_id');
  
  if (!modalId) {
    logInfo('无法获取视频ID，请确保在视频详情页');
    return;
  }

  console.log('currentUrl', currentUrl);
  console.log('urlParams', urlParams);
  console.log('modalId', modalId);
  console.log('interceptedData', interceptedData);

  // 从拦截数据中查找对应的视频信息
  const videoData = interceptedData.find(video => video.awemeId === modalId);
  
  if (!videoData) {
    logInfo('未找到视频数据，请先访问用户主页加载视频列表');
    return;
  }

  logInfo('找到视频数据:', {
    awemeId: videoData.awemeId,
    duration: videoData.duration,
    hasMusicUrl: videoData.musicUrl
  });

  // 显示加载状态（使用页面操作按钮）
  const pageActionBtn = document.querySelector('.page-action-btn');
  let originalText = '';
  if (pageActionBtn) {
    pageActionBtn.classList.add('loading');
    pageActionBtn.disabled = true;

    // 保存原始文本并替换为loading文本
    const textElement = pageActionBtn.querySelector('span:not(.material-icons)');
    if (textElement) {
      originalText = textElement.textContent;
      textElement.textContent = '提取中……';
    }
  }

  // 显示取消提取按钮
  showCancelExtractButton();

  // 创建一个可以取消的操作
  let isCancelled = false;
  currentExtractOperation = {
    cancel: () => {
      isCancelled = true;
      logInfo('用户取消了文案提取操作');
      
      // 恢复按钮状态
      if (pageActionBtn) {
        pageActionBtn.classList.remove('loading');
        pageActionBtn.disabled = false;
        const textElement = pageActionBtn.querySelector('span:not(.material-icons)');
        if (textElement) {
          textElement.textContent = originalText || '提取文案';
        }
      }
      
      // 隐藏取消按钮
      hideCancelExtractButton();
      currentExtractOperation = null;
      
      showError('文案提取已取消');
    }
  };

  // 发送消息给背景脚本，传递视频数据而不是URL
  chrome.runtime.sendMessage({
    type: 'EXTRACT_SINGLE_TEXT',
    videoData: {
      awemeId: videoData.awemeId,
      duration: videoData.duration,
      musicUrl: videoData.musicUrl,
      title: videoData.title, // 额外信息，可能有用
      nickname: videoData.nickname, // 额外信息，可能有用
      cover: videoData.cover,
      video_url : videoData.videoUrl
    }
  }, (response) => {
    // 检查是否已被取消
    if (isCancelled) {
      logInfo('操作已取消，忽略响应');
      return;
    }

    // 隐藏加载状态并恢复原始文本
    if (pageActionBtn) {
      pageActionBtn.classList.remove('loading');
      pageActionBtn.disabled = false;

      const textElement = pageActionBtn.querySelector('span:not(.material-icons)');
      if (textElement) {
        textElement.textContent = originalText || '提取文案';
      }
    }

    // 隐藏取消按钮
    hideCancelExtractButton();
    currentExtractOperation = null;

    if (response && response.success) {
      showResult('文案提取成功', response.data);
    } else {
      showError('文案提取失败: ' + (response?.error || '未知错误'));
    }
  });
}

/**
 * 显示取消提取按钮
 */
function showCancelExtractButton() {
  const cancelBtn = document.querySelector('.cancel-extract-btn');
  if (cancelBtn) {
    cancelBtn.classList.remove('hidden');
  }
}

/**
 * 隐藏取消提取按钮
 */
function hideCancelExtractButton() {
  const cancelBtn = document.querySelector('.cancel-extract-btn');
  if (cancelBtn) {
    cancelBtn.classList.add('hidden');
  }
}

/**
 * 批量提取文案
 */
function extractAllTexts() {
  chrome.runtime.sendMessage({ type: 'GET_USER_AUTH' }, (response) => {
    if (response && response.success && response.data.token) {
      // 用户已登录，继续执行
      logInfo('开始批量提取文案');

      if (interceptedData.length === 0) {
        showError('请先访问用户主页，等待视频数据加载');
        return;
      }

      // 显示加载状态
      showLoadingState('extract-all-text');

      // 收集所有视频URL
      const videoUrls = [];
      interceptedData.forEach(video => {
        if (video.videoUrl) {
          videoUrls.push(video.videoUrl);
        }
      });

      if (videoUrls.length === 0) {
        hideLoadingState('extract-all-text');
        showError('未找到有效的视频数据');
        return;
      }

      // 发送批量处理请求
      chrome.runtime.sendMessage({
        type: 'EXTRACT_ALL_TEXTS',
        videoUrls: videoUrls
      }, (response) => {
        hideLoadingState('extract-all-text');

        if (response && response.success) {
          showResult('批量文案提取成功', response.data);
        } else {
          showError('批量文案提取失败: ' + (response?.error || '未知错误'));
        }
      });
    } else {
      // 用户未登录，显示提示弹窗
      showLoginPromptModal();
    }
  });
}

/**
 * 显示下载报告按钮
 */
function showDownloadReportButton(reportUrl) {
  const downloadReportBtn = document.querySelector('.download-report-btn');
  if (downloadReportBtn) {
    // 存储报告链接
    analysisReportUrl = reportUrl;
    
    // 显示下载报告按钮
    downloadReportBtn.classList.remove('hidden');
    downloadReportBtn.setAttribute('data-report-url', reportUrl);
    
    logInfo('下载报告按钮已显示，报告链接:', reportUrl);
  }
}

/**
 * 隐藏下载报告按钮
 */
function hideDownloadReportButton() {
  const downloadReportBtn = document.querySelector('.download-report-btn');
  if (downloadReportBtn) {
    downloadReportBtn.classList.add('hidden');
    analysisReportUrl = null;
    logInfo('下载报告按钮已隐藏');
  }
}

/**
 * 分析主页
 */
function analyzeProfile() {
  logInfo('开始分析主页');

  // 隐藏下载报告按钮（重新开始分析）
  hideDownloadReportButton();

  // 实时从HTML页面获取用户数据
  const currentUserData = parseUserDataFromHTML();
  
  // 检查是否成功获取到用户数据
  if (!currentUserData.nickname) {
    showError('无法获取用户主页信息，请确保页面已完全加载');
    return;
  }

  // 检查是否有视频数据
  if (interceptedData.length === 0) {
    showError('请先等待视频数据加载，或滚动页面加载更多视频');
    return;
  }

  // 显示加载状态（使用页面操作按钮）
  const pageActionBtn = document.querySelector('.page-action-btn');
  if (pageActionBtn) {
    pageActionBtn.classList.add('loading');
    pageActionBtn.disabled = true;
  }

  // 准备作者信息数据（按照API文档格式，使用实时获取的数据）
  const authorInfo = JSON.stringify({
    user: {
      following_count: currentUserData.following_count || 0,
      nickname: currentUserData.nickname || '',
      total_favorited: currentUserData.total_favorited || 0,
      user_age: currentUserData.user_age || 0,
      follower_count: currentUserData.follower_count || 0,
      aweme_count: interceptedData.length // 使用视频数据的数量作为作品数
    }
  });

  // 准备视频数据，只提取必要的字段
  const filteredVideoData = interceptedData.map(video => ({
    标题: video.title || '',
    赞: video.diggCount || 0,
    评: video.commentCount || 0,
    藏: video.collectCount || 0,
    享: video.shareCount || 0
  }));
  
  const videoData = JSON.stringify(filteredVideoData);

  logInfo('准备发送分析数据:', {
    userInfo: currentUserData,
    videoCount: filteredVideoData.length
  });

  // 发送分析请求到background脚本
  chrome.runtime.sendMessage({
    type: 'ANALYZE_PROFILE',
    data: {
      author_info: authorInfo,
      video_data: videoData
    },
    userUrl: window.location.href
  }, (response) => {
    // 隐藏加载状态
    if (pageActionBtn) {
      pageActionBtn.classList.remove('loading');
      pageActionBtn.disabled = false;
    }

    if (response && response.success) {
      // 显示成功消息
      showSuccess('主页分析完成！点击下载报告按钮获取分析结果');
      
      // 显示下载报告按钮，传入Word文档链接
      showDownloadReportButton(response.data);
    } else {
      showError('主页分析失败: ' + (response?.error || '未知错误'));
    }
  });
}

/**
 * 处理下载分析报告
 */
function handleDownloadReport(reportUrl) {
  logInfo('开始下载分析报告:', reportUrl);
  
  try {
    // 显示下载按钮加载状态
    const downloadReportBtn = document.querySelector('.download-report-btn');
    if (downloadReportBtn) {
      downloadReportBtn.classList.add('loading');
      downloadReportBtn.disabled = true;
    }

    // 获取用户昵称用于文件命名
    const currentUserData = parseUserDataFromHTML();
    const nickname = currentUserData.nickname || '用户';
    
    // 创建隐藏的下载链接
    const downloadLink = document.createElement('a');
    downloadLink.href = reportUrl;
    downloadLink.style.display = 'none';
    
    // 添加到页面并触发下载
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    
    // 显示成功消息
    showSuccess('报告下载已开始');
    
    logInfo('报告下载链接已触发');
  } catch (error) {
    logError('下载报告失败:', error);
    showError('下载报告失败: ' + error.message);
  } finally {
    // 恢复按钮状态
    const downloadReportBtn = document.querySelector('.download-report-btn');
    if (downloadReportBtn) {
      downloadReportBtn.classList.remove('loading');
      downloadReportBtn.disabled = false;
    }
  }
}

/**
 * 清除拦截数据
 */
function clearInterceptedData() {
  interceptedData = [];
  updateInterceptedDataDisplay();

  // 同时清理本地存储
  chrome.runtime.sendMessage({
    type: 'CLEAR_STORAGE'
  }, (response) => {
    if (response && response.success) {
      logInfo('已清除拦截数据和本地存储');
    } else {
      logInfo('已清除拦截数据（本地存储清理失败）');
    }
  });
}

/**
 * 显示加载状态
 */
function showLoadingState(buttonClass) {
  const button = document.querySelector('.' + buttonClass);
  if (button) {
    button.classList.add('loading');
    button.disabled = true;
  }
}

/**
 * 隐藏加载状态
 */
function hideLoadingState(buttonClass) {
  const button = document.querySelector('.' + buttonClass);
  if (button) {
    button.classList.remove('loading');
    button.disabled = false;
  }
}

/**
 * 显示结果（弹窗模式）
 */
function showResult(message, data) {
  // 如果是单个文案提取结果，使用弹窗显示
  if (data && data.content && data.title) {
    showExtractModal(message, data);
  } else {
    // 其他类型的结果，仍使用侧边栏显示
    const resultContainer = document.querySelector('.result-container');
    if (resultContainer) {
      resultContainer.innerHTML = `
        <div class="result-success">
          <div class="result-title">${message}</div>
          <div class="result-content">${JSON.stringify(data, null, 2)}</div>
        </div>
      `;
    }
  }
}

/**
 * 添加弹窗样式
 */
function addModalStyles() {
  // 检查是否已经添加过样式
  if (document.getElementById('extract-modal-styles')) {
    return;
  }

  const modalStyles = `
    <style id="extract-modal-styles">
    .extract-modal-overlay {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: rgba(0, 0, 0, 0.5) !important;
      display: flex !important;
      justify-content: center !important;
      align-items: center !important;
      z-index: 999999 !important;
      opacity: 0 !important;
      transition: opacity 0.3s ease !important;
    }
    
    .extract-modal-overlay.extract-modal-show {
      opacity: 1 !important;
    }
    
    .extract-modal-container {
      background: #ffffff !important;
      border-radius: 12px !important;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2) !important;
      max-width: 600px !important;
      width: 90vw !important;
      max-height: 80vh !important;
      overflow: hidden !important;
      transform: translateY(20px) !important;
      transition: transform 0.3s ease !important;
    }
    
    .extract-modal-overlay.extract-modal-show .extract-modal-container {
      transform: translateY(0) !important;
    }
    
    .extract-modal-header {
      display: flex !important;
      justify-content: space-between !important;
      align-items: center !important;
      padding: 20px 24px !important;
      border-bottom: 1px solid #e5e7eb !important;
      background: #f9fafb !important;
    }
    
    .extract-modal-title {
      display: flex !important;
      align-items: center !important;
      gap: 8px !important;
      font-size: 18px !important;
      font-weight: 600 !important;
      color: #1f2937 !important;
    }
    
    .extract-modal-close {
      background: none !important;
      border: none !important;
      cursor: pointer !important;
      padding: 8px !important;
      border-radius: 6px !important;
      color: #6b7280 !important;
      transition: all 0.2s ease !important;
    }
    
    .extract-modal-close:hover {
      background: #e5e7eb !important;
      color: #374151 !important;
    }
    
    .extract-modal-content {
      padding: 24px !important;
      max-height: 50vh !important;
      overflow-y: auto !important;
    }
    
    .extract-modal-item {
      margin-bottom: 20px !important;
    }
    
    .extract-modal-item:last-child {
      margin-bottom: 0 !important;
    }
    
    .extract-modal-label {
      display: flex !important;
      align-items: center !important;
      gap: 8px !important;
      font-size: 14px !important;
      font-weight: 500 !important;
      color: #374151 !important;
      margin-bottom: 8px !important;
    }
    
    .extract-modal-value {
      background: #f9fafb !important;
      border: 1px solid #e5e7eb !important;
      border-radius: 6px !important;
      padding: 12px !important;
      font-size: 14px !important;
      line-height: 1.5 !important;
      color: #1f2937 !important;
    }
    
    .extract-modal-content-text {
      white-space: pre-wrap !important;
    }
    
    .extract-modal-image img {
      max-width: 100% !important;
      height: auto !important;
      border-radius: 6px !important;
      loading: lazy !important;
    }
    
    .extract-modal-actions {
      display: flex !important;
      gap: 12px !important;
      padding: 20px 24px !important;
      border-top: 1px solid #e5e7eb !important;
      background: #f9fafb !important;
    }
    
    .extract-modal-btn {
      display: flex !important;
      align-items: center !important;
      gap: 6px !important;
      padding: 10px 16px !important;
      border: 1px solid #d1d5db !important;
      border-radius: 6px !important;
      background: #ffffff !important;
      color: #374151 !important;
      font-size: 14px !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
    }
    
    .extract-modal-btn:hover {
      background: #f3f4f6 !important;
      border-color: #9ca3af !important;
    }
    
    .extract-modal-btn-debug {
      background: #fef3c7 !important;
      border-color: #f59e0b !important;
      color: #92400e !important;
    }
    
    .extract-modal-btn-debug:hover {
      background: #fde68a !important;
      border-color: #d97706 !important;
    }
    </style>
  `;

  document.head.insertAdjacentHTML('beforeend', modalStyles);
}

/**
 * 显示文案提取结果弹窗
 */
function showExtractModal(title, data) {
  // 移除已存在的弹窗
  const existingModal = document.getElementById('extract-result-modal');
  if (existingModal) {
    existingModal.remove();
  }

  // 创建弹窗HTML
  const modalHTML = `
    <div id="extract-result-modal" class="extract-modal-overlay">
      <div class="extract-modal-container">
        <div class="extract-modal-header">
          <div class="extract-modal-title">
            <span class="material-icons">check_circle</span>
            <span>${title}</span>
          </div>
          <button class="extract-modal-close">
            <span class="material-icons">close</span>
          </button>
        </div>
        
        <div class="extract-modal-content">
          <div class="extract-modal-item">
            <div class="extract-modal-label">
              <span class="material-icons">title</span>
              视频标题
            </div>
            <div class="extract-modal-value">${data.title}</div>
          </div>
          
          <div class="extract-modal-item">
            <div class="extract-modal-label">
              <span class="material-icons">description</span>
              文案内容
            </div>
            <div class="extract-modal-value extract-modal-content-text">${data.content}</div>
          </div>
          
          ${data.cover_url ? `
          <div class="extract-modal-item">
            <div class="extract-modal-label">
              <span class="material-icons">image</span>
              封面图片
            </div>
            <div class="extract-modal-image">
              <img src="${data.cover_url}" alt="视频封面" loading="lazy" style="max-width: 200px; max-height: 150px; object-fit: cover;">
            </div>
          </div>
          ` : ''}
        </div>
        
        <div class="extract-modal-actions">
          <button class="extract-modal-btn extract-modal-btn-copy" data-copy="${data.content}">
            <span class="material-icons">content_copy</span>
            复制文案
          </button>
          ${data.debug_url ? `
          <button class="extract-modal-btn extract-modal-btn-debug" onclick="window.open('${data.debug_url}', '_blank')">
            <span class="material-icons">bug_report</span>
            调试信息
          </button>
          ` : ''}
          <button class="extract-modal-btn extract-modal-btn-close">
            <span class="material-icons">done</span>
            完成
          </button>
        </div>
      </div>
    </div>
  `;

  // 添加到页面
  document.body.insertAdjacentHTML('beforeend', modalHTML);

  // 确保弹窗样式正确应用
  addModalStyles();

  // 添加事件监听
  const modal = document.getElementById('extract-result-modal');
  const closeBtn = modal.querySelector('.extract-modal-close');
  const closeActionBtn = modal.querySelector('.extract-modal-btn-close');
  const copyBtn = modal.querySelector('.extract-modal-btn-copy');

  // 关闭弹窗
  const closeModal = () => {
    modal.classList.add('extract-modal-fade-out');
    setTimeout(() => {
      modal.remove();
    }, 300);
  };

  closeBtn.addEventListener('click', closeModal);
  closeActionBtn.addEventListener('click', closeModal);

  // 点击背景关闭
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closeModal();
    }
  });

  // 复制文案
  if (copyBtn) {
    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(data.content);
        copyBtn.innerHTML = `
          <span class="material-icons">check</span>
          已复制
        `;
        setTimeout(() => {
          copyBtn.innerHTML = `
            <span class="material-icons">content_copy</span>
            复制文案
          `;
        }, 2000);
      } catch (err) {
        logError('复制失败:', err);
      }
    });
  }

  // 使用requestAnimationFrame优化动画性能
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      modal.classList.add('extract-modal-show');
    });
  });
}

/**
 * 显示成功消息
 */
function showSuccess(message) {
  // 创建临时提示元素
  const toast = document.createElement('div');
  toast.className = 'success-toast';
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #10b981;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 14px;
    z-index: 10000;
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    transition: all 0.3s ease;
  `;

  document.body.appendChild(toast);

  // 3秒后自动移除
  setTimeout(() => {
    if (toast.parentNode) {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => {
        if (toast.parentNode) {
          document.body.removeChild(toast);
        }
      }, 300);
    }
  }, 3000);
}

/**
 * 添加登录提示弹窗的样式
 */
function addLoginPromptModalStyles() {
  if (document.getElementById('login-prompt-modal-styles')) {
    return;
  }

  const modalStyles = `
    <style id="login-prompt-modal-styles">
    .login-prompt-overlay {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: rgba(0, 0, 0, 0.5) !important;
      backdrop-filter: blur(4px) !important;
      z-index: 999999 !important;
      display: flex !important;
      justify-content: center !important;
      align-items: center !important;
      opacity: 0 !important;
      transition: opacity 0.3s ease !important;
      font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, sans-serif !important;
    }
    
    .login-prompt-overlay.show {
      opacity: 1 !important;
    }
    
    .login-prompt-container {
      background: #ffffff !important;
      border-radius: 16px !important;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2) !important;
      max-width: 420px !important;
      width: 90vw !important;
      text-align: center !important;
      padding: 32px 24px 24px !important;
      transform: scale(0.95) !important;
      transition: transform 0.3s ease !important;
    }

    .login-prompt-overlay.show .login-prompt-container {
      transform: scale(1) !important;
    }
    
    .login-prompt-icon {
      font-size: 48px !important;
      color: #000000 !important;
      margin-bottom: 16px !important;
    }

    .login-prompt-title {
      font-size: 20px !important;
      font-weight: 600 !important;
      color: #1d1d1f !important;
      margin-bottom: 8px !important;
    }
    
    .login-prompt-message {
      font-size: 15px !important;
      line-height: 1.6 !important;
      color: #6c757d !important;
      margin-bottom: 24px !important;
    }
    
    .login-prompt-button {
      background: #000000 !important;
      color: #ffffff !important;
      border: none !important;
      padding: 14px 24px !important;
      border-radius: 8px !important;
      font-size: 15px !important;
      font-weight: 500 !important;
      cursor: pointer !important;
      width: 100% !important;
      transition: all 0.2s ease !important;
    }
    
    .login-prompt-button:hover {
      background: #333333 !important;
      transform: translateY(-2px) !important;
    }
    </style>
  `;

  document.head.insertAdjacentHTML('beforeend', modalStyles);
}


/**
 * 显示需要登录的提示弹窗
 */
function showLoginPromptModal() {
  // 移除已存在的弹窗
  const existingModal = document.getElementById('login-prompt-modal');
  if (existingModal) {
    existingModal.remove();
  }

  // 确保样式已注入
  addLoginPromptModalStyles();

  // 创建弹窗HTML
  const modalHTML = `
    <div id="login-prompt-modal" class="login-prompt-overlay">
      <div class="login-prompt-container">
        <div class="login-prompt-icon material-icons">lock</div>
        <div class="login-prompt-title">此功能需要登录</div>
        <div class="login-prompt-message">
          请点击浏览器右上角的插件图标完成登录，然后再使用此功能。
        </div>
        <button class="login-prompt-button">好的，我知道了</button>
      </div>
    </div>
  `;

  // 添加到页面
  document.body.insertAdjacentHTML('beforeend', modalHTML);

  const modal = document.getElementById('login-prompt-modal');
  const closeButton = modal.querySelector('.login-prompt-button');

  const closeModal = () => {
    modal.classList.remove('show');
    setTimeout(() => {
      modal.remove();
    }, 300);
  };

  // 事件监听
  closeButton.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closeModal();
    }
  });

  // 动画效果
  requestAnimationFrame(() => {
    modal.classList.add('show');
  });
}


/**
 * 显示错误消息
 */
function showError(message) {
  // 创建临时提示元素
  const toast = document.createElement('div');
  toast.className = 'error-toast';
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #ef4444;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 14px;
    z-index: 10000;
    box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
    transition: all 0.3s ease;
  `;

  document.body.appendChild(toast);

  // 3秒后自动移除
  setTimeout(() => {
    if (toast.parentNode) {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => {
        if (toast.parentNode) {
          document.body.removeChild(toast);
        }
      }, 300);
    }
  }, 3000);
}

// showExtractResult 函数已删除 - 不再需要单独的文案提取结果显示

/**
 * 初始化内容脚本
 */
function initializeContentScript() {
  logInfo('开始初始化内容脚本，页面状态:', document.readyState);

  // 🚀 优先级1: 立即注入拦截器（不管是否为目标页面）
  // 现在在document_start阶段就注入，确保在任何API请求之前就开始拦截
  injectInterceptorScript();
  setupInterceptorListener();
  logInfo('拦截器已在页面早期注入');

  // 等待DOM准备好后再初始化其他功能
  const initializeAfterDOM = () => {
    // 初始化URL监听器（无论是否为目标页面都要监听）
    initializeUrlMonitoring();

    // 检查是否是目标页面
    if (!isTargetPage()) {
      logInfo('不是目标页面，但拦截器已注入');
      return;
    }

    // 创建侧边栏
    setTimeout(createSidebarContainer, 1000);
    logInfo('侧边栏创建已安排');
  };

  // 根据当前页面状态决定何时初始化
  if (document.readyState === 'loading') {
    // 页面还在加载，等待DOM准备好
    document.addEventListener('DOMContentLoaded', initializeAfterDOM);
  } else {
    // DOM已经准备好，立即初始化
    initializeAfterDOM();
  }

  logInfo('内容脚本初始化完成');
}

// 启动内容脚本
initializeContentScript();
