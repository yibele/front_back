/**
 * 背景服务工作脚本 (Service Worker)
 * 负责处理API调用、存储管理和消息传递
 */

// 全局变量
let serverConfig = {
  baseUrl: 'http://localhost:8080', // 连接到本地Go后端
  apiKey: null,
  isAuthenticated: false
};

// 用户认证信息
let userAuth = {
  token: null,
  userId: null,
  credits: 0
};

/**
 * 日志工具函数
 */
function logInfo(message, data = null) {
  console.log(`[聚抖自媒体大师-BG] ${message}`, data || '');
}

function logError(message, error = null) {
  console.error(`[聚抖自媒体大师-BG] ${message}`, error || '');
}

/**
 * 插件安装时的初始化
 */
chrome.runtime.onInstalled.addListener(async (details) => {
  logInfo('插件已安装/更新', details);
  
  // 初始化存储
  await initializeStorage();
  
  // 设置默认配置
  await loadConfiguration();
});

/**
 * 插件启动时的初始化
 */
chrome.runtime.onStartup.addListener(async () => {
  logInfo('插件启动');
  await loadConfiguration();
});

/**
 * Service Worker启动时的初始化
 * 这确保每次Service Worker重启时都会加载用户状态
 */
(async () => {
  try {
    logInfo('Service Worker初始化开始');
    await initializeStorage();
    await loadConfiguration();
    logInfo('Service Worker初始化完成', { 
      userAuth: userAuth.userId ? 'logged_in' : 'guest',
      serverConfig: serverConfig.baseUrl 
    });
  } catch (error) {
    logError('Service Worker初始化失败:', error);
  }
})();

// startPeriodicCleanup 函数已删除 - 不再需要定期清理

/**
 * 处理清理存储请求
 */
async function handleClearStorage(sendResponse) {
  try {
    await chrome.storage.local.clear();
    logInfo('所有本地存储已清除');
    sendResponse({
      success: true,
      message: '存储已清除'
    });
  } catch (error) {
    logError('清除存储失败:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

// cleanupStorage 和 forceCleanupStorage 函数已删除 - 不再需要复杂的存储清理

/**
 * 消息监听器 - 处理来自内容脚本的消息
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  logInfo('收到消息:', message.type);
  
  // 异步处理消息
  handleMessage(message, sender, sendResponse);
  
  // 返回true表示异步响应
  return true;
});

/**
 * 处理消息的主要函数
 */
async function handleMessage(message, sender, sendResponse) {
  logInfo('收到消息', { type: message.type, sender: sender?.tab?.url || 'popup' });
  
  try {
    switch (message.type) {
      case 'EXTRACT_SINGLE_TEXT':
        await handleExtractSingleText(message.videoData, sendResponse);
        break;
        
      case 'EXTRACT_ALL_TEXTS':
        await handleExtractAllTexts(message.videoUrls, sendResponse);
        break;
        
      case 'ANALYZE_PROFILE':
        await handleAnalyzeProfile(message.data, message.userUrl, sendResponse);
        break;
        
      case 'GET_USER_AUTH':
        sendResponse({
          success: true,
          data: userAuth
        });
        break;
        
      case 'GET_USER_PROFILE':
        await handleGetUserProfile(sendResponse);
        break;
        
      case 'GET_CREDITS_HISTORY':
        await handleGetCreditsHistory(sendResponse);
        break;
        
      case 'LOGIN':
        await handleLogin(message.credentials, sendResponse);
        break;
        
      case 'LOGOUT':
        await handleLogout(sendResponse);
        break;
        
      case 'SAVE_AUTH':
        await handleSaveAuth(message.authData, sendResponse);
        break;
        
      case 'CLEAR_STORAGE':
        await handleClearStorage(sendResponse);
        break;
        
      default:
        logError('未知消息类型:', message.type);
        sendResponse({
          success: false,
          error: '未知消息类型'
        });
    }
  } catch (error) {
    logError('处理消息失败:', error);
    sendResponse({
      success: false,
      error: error.message || '处理失败'
    });
  }
}

/**
 * 初始化存储
 */
async function initializeStorage() {
  const defaultData = {
    userAuth: {
      token: null,
      userId: null,
      credits: 0
    },
    serverConfig: {
      baseUrl: 'http://localhost:8080', // 修正默认后端地址
      timeout: 30000
    },
    preferences: {
      autoSave: true,
      maxStorageItems: 100
    }
  };
  
  // 检查并设置默认值
  for (const [key, value] of Object.entries(defaultData)) {
    const existing = await chrome.storage.local.get(key);
    if (!existing[key]) {
      await chrome.storage.local.set({ [key]: value });
    }
  }
  
  logInfo('存储初始化完成');
}

/**
 * 加载配置
 */
async function loadConfiguration() {
  try {
    const result = await chrome.storage.local.get(['userAuth', 'serverConfig']);
    
    if (result.userAuth) {
      userAuth = { ...userAuth, ...result.userAuth };
      logInfo('从存储中恢复用户状态:', { 
        userId: userAuth.userId, 
        hasToken: !!userAuth.token,
        credits: userAuth.credits 
      });
    }
    
    if (result.serverConfig) {
      serverConfig = { ...serverConfig, ...result.serverConfig };
    }
    
    logInfo('配置加载完成', { userAuth: userAuth.userId ? 'logged_in' : 'guest' });
  } catch (error) {
    logError('加载配置失败:', error);
  }
}

// handleInterceptedData 函数已删除 - 不再需要存储拦截数据

/**
 * 处理单个文案提取
 */
async function handleExtractSingleText(videoData, sendResponse) {
  logInfo('开始提取单个文案:', {
    awemeId: videoData.awemeId,
    duration: videoData.duration,
    hasMusicUrl: !!videoData.musicUrl
  });
  
  try {
    // 检查用户认证
    if (!userAuth.token) {
      sendResponse({
        success: false,
        error: '请先登录'
      });
      return;
    }
    
    // 检查积分余额（文案提取通常消耗1积分）
    if (userAuth.credits < 1) {
      sendResponse({
        success: false,
        error: '积分不足，无法提取文案'
      });
      return;
    }
    
    // 验证必需的视频数据
    if (!videoData.awemeId || !videoData.duration) {
      sendResponse({
        success: false,
        error: '视频数据不完整，缺少awemeId或duration'
      });
      return;
    }
    
    // 调用后端API进行文案提取
    const response = await fetch(`${serverConfig.baseUrl}/api/v1/douyin/video/caption`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${userAuth.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        aweme_id: videoData.awemeId,
        duration: videoData.duration,
        music_url: videoData.musicUrl || '',
        title: videoData.title || '',
        cover: videoData.cover || '',
        video_url: videoData.video_url || ''
      })
    });
    
    const data = await response.json();
    
    if (response.ok && data.content !== undefined) {
      // 刷新用户积分
      await refreshUserCredits();
      
      sendResponse({
        success: true,
        data: {
          content: data.content || '未获取到文案内容',
          title: data.title || videoData.title || '未获取到标题',
          cover_url: data.cover_url || videoData.cover || '',
          downurl: data.downurl || videoData.video_url || '',
          aweme_id: data.aweme_id || videoData.awemeId,
          debug_url: data.debug_url || ''
        }
      });
    } else {
      sendResponse({
        success: false,
        error: data.error || '提取失败'
      });
    }
  } catch (error) {
    logError('提取单个文案失败:', error);
    sendResponse({
      success: false,
      error: error.message || '网络请求失败'
    });
  }
}

/**
 * 处理批量文案提取
 */
async function handleExtractAllTexts(videoUrls, sendResponse) {
  logInfo('开始批量提取文案，视频数量:', videoUrls.length);
  
  try {
    // 检查用户认证
    if (!userAuth.token) {
      sendResponse({
        success: false,
        error: '请先登录'
      });
      return;
    }
    
    // 检查积分是否足够
    const requiredCredits = videoUrls.length * 2; // 假设每个视频需要2积分
    if (userAuth.credits < requiredCredits) {
      sendResponse({
        success: false,
        error: `积分不足，需要${requiredCredits}积分，当前${userAuth.credits}积分`
      });
      return;
    }
    
    // 调用后端批量提取API（需要后端实现）
    const apiResponse = await callServerAPI('/api/v1/douyin/home/videos-with-captions', {
      method: 'POST',
      body: {
        videoUrls: videoUrls,
        type: 'batch'
      }
    });
    
    if (apiResponse.success) {
      // 更新用户积分信息
      await refreshUserCredits();
      
      sendResponse({
        success: true,
        data: apiResponse.data
      });
    } else {
      sendResponse({
        success: false,
        error: apiResponse.error || '批量提取失败'
      });
    }
  } catch (error) {
    logError('批量提取文案失败:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * 处理主页分析
 */
async function handleAnalyzeProfile(requestData, userUrl, sendResponse) {
  logInfo('开始分析主页，数据:', requestData);
  
  try {
    // 直接调用Coze API进行主页分析
    const response = await fetch('https://api.coze.cn/v1/workflow/run', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer sat_fNtvRmUkaSfs8EBzBQWyC4UfzZd7DftlzZJRUYs70scDARwjQEcI7TpoyOOVIRRc',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        workflow_id: '7523977048177279027',
        parameters: {
          author_info: requestData.author_info,
          video_data: requestData.video_data
        },
        is_async: false
      })
    });

    if (!response.ok) {
      throw new Error(`API请求失败: ${response.status} ${response.statusText}`);
    }

    const result = await response.json();
    
    if (result.code === 0) {
      // 解析返回的数据，提取Word文档下载链接
      let documentUrl;
      try {
        const parsedData = JSON.parse(result.data);
        logInfo('解析的API数据:', parsedData);
        
        // 根据实际的API返回格式提取下载链接
        if (parsedData.data && typeof parsedData.data === 'string' && parsedData.data.startsWith('http')) {
          // 如果data字段是直接的URL链接
          documentUrl = parsedData.data;
        } else if (parsedData.content_type === 1 && parsedData.data) {
          // 根据console显示的格式，文档链接在data字段中
          documentUrl = parsedData.data;
        } else {
          // 其他可能的字段名
          documentUrl = parsedData.document_url || parsedData.download_url || parsedData.url || parsedData.data || result.data;
        }
      } catch (e) {
        // 如果解析失败，假设直接就是下载链接
        logInfo('JSON解析失败，使用原始数据:', result.data);
        documentUrl = result.data;
      }

      sendResponse({
        success: true,
        data: documentUrl,
        result: result
      });
      
      logInfo('主页分析成功完成，最终文档链接:', documentUrl);
    } else {
      throw new Error(`API返回错误: ${result.msg || '未知错误'}`);
    }
  } catch (error) {
    logError('主页分析失败:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * 获取用户详细信息
 */
async function handleGetUserProfile(sendResponse) {
  logInfo('获取用户详细信息');
  
  try {
    if (!userAuth.token) {
      sendResponse({
        success: false,
        error: '用户未登录'
      });
      return;
    }

    const response = await fetch(`${serverConfig.baseUrl}/api/v1/me`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${userAuth.token}`,
        'Content-Type': 'application/json'
      }
    });
    
    const data = await response.json();
    
    if (response.ok) {
      // 更新本地用户信息
      userAuth.credits = data.TotalCredits || 0;
      userAuth.userID = data.ID;
      await updateUserAuth(userAuth);
      
      sendResponse({
        success: true,
        data: data
      });
    } else {
      sendResponse({
        success: false,
        error: data.error || '获取用户信息失败'
      });
    }
  } catch (error) {
    logError('获取用户信息失败:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * 获取积分记录
 */
async function handleGetCreditsHistory(sendResponse) {
  logInfo('获取积分记录');
  
  try {
    if (!userAuth.token) {
      sendResponse({
        success: false,
        error: '用户未登录'
      });
      return;
    }

    const response = await fetch(`${serverConfig.baseUrl}/api/v1/credits/history`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${userAuth.token}`,
        'Content-Type': 'application/json'
      }
    });
    
    const data = await response.json();
    
    if (response.ok) {
      sendResponse({
        success: true,
        data: data
      });
    } else {
      sendResponse({
        success: false,
        error: data.error || '获取积分记录失败'
      });
    }
  } catch (error) {
    logError('获取积分记录失败:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * 测试网络连接
 */
async function testNetworkConnection() {
  try {
    const response = await fetch(`${serverConfig.baseUrl}/api/v1/health`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return { success: true, status: response.status };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * 处理用户登录
 */
async function handleLogin(credentials, sendResponse) {
  logInfo('处理用户登录', { username: credentials.username, baseUrl: serverConfig.baseUrl });
  
  // 首先测试网络连接
  const networkTest = await testNetworkConnection();
  logInfo('网络连接测试', networkTest);
  
  if (!networkTest.success) {
    logError('网络连接测试失败，尝试继续登录...');
  }
  
  try {
    const requestBody = {
      phone: credentials.username, // 前端使用username，后端期望phone
      password: credentials.password
    };
    
    logInfo('发送登录请求', { url: `${serverConfig.baseUrl}/api/v1/login`, body: requestBody });
    
    // 调用真实的后端API
    const fetchOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    };
    
    logInfo('Fetch配置', fetchOptions);
    
    const response = await fetch(`${serverConfig.baseUrl}/api/v1/login`, fetchOptions);
    
    const data = await response.json();
    
    logInfo('登录API响应', { status: response.status, ok: response.ok, data: data });

    if (response.ok && data.token) {
      const profile = data.profile || {};
      
      // 统一数据结构，确保内存、存储和发送给UI的数据一致
      const newAuthData = {
        token: data.token,
        userId: profile.Username || profile.Phone || credentials.username,
        credits: profile.total_credits || 0,
        userID: profile.ID || null,
        membership: profile.membership || null,
        profile: profile // 包含完整的profile对象
      };

      userAuth = newAuthData; // 更新内存状态
      await updateUserAuth(userAuth); // 持久化正确的数据结构

      logInfo('用户登录成功:', userAuth.userId);

      sendResponse({
        success: true,
        data: newAuthData
      });
    } else {
      sendResponse({
        success: false,
        error: data.error || '登录失败'
      });
    }
  } catch (error) {
    logError('登录失败:', {
      message: error.message,
      stack: error.stack,
      name: error.name,
      cause: error.cause
    });
    
    // 特殊处理网络错误
    let errorMessage = error.message;
    if (error.message.includes('Failed to fetch')) {
      errorMessage = '网络连接失败，请检查：1) 后端服务是否运行 2) 插件权限是否正确 3) 防火墙设置';
    }
    
    sendResponse({
      success: false,
      error: errorMessage,
      details: {
        originalError: error.message,
        serverUrl: serverConfig.baseUrl
      }
    });
  }
}

/**
 * 保存认证数据（用于popup直接登录的备用方案）
 */
async function handleSaveAuth(authData, sendResponse) {
  logInfo('保存认证数据', { userId: authData.userId });
  
  try {
    userAuth = {
      token: authData.token,
      userId: authData.userId,
      credits: authData.credits || 0,
      userID: authData.userID || null,
      membership: authData.membership || null
    };
    
    await updateUserAuth(userAuth);
    
    logInfo('认证数据已保存');
    
    sendResponse({
      success: true
    });
  } catch (error) {
    logError('保存认证数据失败:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * 处理用户退出
 */
async function handleLogout(sendResponse) {
  logInfo('处理用户退出');
  
  try {
    userAuth = {
      token: null,
      userId: null,
      credits: 0
    };
    
    await updateUserAuth(userAuth);
    
    logInfo('用户已退出');
    
    sendResponse({
      success: true
    });
  } catch (error) {
    logError('退出失败:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * 调用服务器API的通用函数
 */
async function callServerAPI(endpoint, options = {}) {
  const url = serverConfig.baseUrl + endpoint;
  
  const defaultOptions = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  };
  
  if (userAuth.token) {
    defaultOptions.headers['Authorization'] = `Bearer ${userAuth.token}`;
  }
  
  const finalOptions = {
    ...defaultOptions,
    ...options,
    headers: {
      ...defaultOptions.headers,
      ...(options.headers || {})
    }
  };
  
  if (finalOptions.body && typeof finalOptions.body === 'object') {
    finalOptions.body = JSON.stringify(finalOptions.body);
  }
  
  logInfo(`调用API: ${endpoint}`);
  
  try {
    const response = await fetch(url, finalOptions);
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || data.message || `HTTP ${response.status}`);
    }
    
    return {
      success: true,
      data: data
    };
  } catch (error) {
    logError(`API调用失败 ${endpoint}:`, error);
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * 更新用户认证信息
 */
async function updateUserAuth(authData) {
  await chrome.storage.local.set({ userAuth: authData });
}

/**
 * 刷新用户积分信息
 */
async function refreshUserCredits() {
  if (!userAuth.token) return;
  
  try {
    const response = await fetch(`${serverConfig.baseUrl}/api/v1/me`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${userAuth.token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (response.ok) {
      const userData = await response.json();
      userAuth.credits = userData.TotalCredits || 0;
      await updateUserAuth(userAuth);
      
      // 通知前端更新积分显示
      try {
        await chrome.runtime.sendMessage({
          type: 'UPDATE_USER_CREDITS',
          credits: userAuth.credits
        });
      } catch (e) {
        // 忽略发送消息失败（可能没有接收者）
      }
    }
  } catch (error) {
    logError('刷新用户积分失败:', error);
  }
}

/**
/**
 * 标签页更新监听
 */
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('douyin.com/user')) {
    logInfo('检测到抖音用户页面:', tab.url);
  }
});

logInfo('背景脚本已启动');
