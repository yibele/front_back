/**
 * 注入脚本入口文件
 * 负责网络请求拦截和数据提取
 */

// 日志工具函数
const LOG_LEVELS = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3
};

let currentLogLevel = LOG_LEVELS.INFO;

function info(module, message, data) {
  if (currentLogLevel <= LOG_LEVELS.INFO) {
    console.info(`[${new Date().toISOString()}] [INFO] [${module}] ${message}`, data || '');
  }
}

function warn(module, message, data) {
  if (currentLogLevel <= LOG_LEVELS.WARN) {
    console.warn(`[${new Date().toISOString()}] [WARN] [${module}] ${message}`, data || '');
  }
}

function error(module, message, data) {
  if (currentLogLevel <= LOG_LEVELS.ERROR) {
    console.error(`[${new Date().toISOString()}] [ERROR] [${module}] ${message}`, data || '');
  }
}

// 网络拦截器相关变量
const TARGET_APIS = [
  {
    pattern: /aweme\/v1\/web\/aweme\/post/,
    name: '博主首页视频接口'
  }
];

function isTargetAPI(url) {
  return TARGET_APIS.find(api => api.pattern.test(url));
}

/**
 * 初始化网络拦截器
 */
function initializeNetworkInterceptor() {
  info('NetworkInterceptor', '初始化网络拦截器');

  // 拦截XMLHttpRequest
  interceptXMLHttpRequest();

  // 拦截Fetch API
  interceptFetch();

  info('NetworkInterceptor', '网络拦截器初始化完成');
}

/**
 * 拦截XMLHttpRequest
 */
function interceptXMLHttpRequest() {
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...args) {
    this._url = url;
    this._method = method;
    return originalOpen.apply(this, [method, url, ...args]);
  };

  XMLHttpRequest.prototype.send = function(body) {
    const targetAPI = isTargetAPI(this._url);
    if (targetAPI) {
      info('NetworkInterceptor', `拦截到目标API请求: ${targetAPI.name}`, {
        url: this._url,
        method: this._method
      });

      // 保存原始回调
      const originalOnLoad = this.onload;
      const originalOnError = this.onerror;

      this.onload = function(event) {
        try {
          handleApiResponse(this._url, this._method, this.responseText, targetAPI);
        } catch (err) {
          error('NetworkInterceptor', '处理API响应失败:', err);
        }

        // 调用原始回调
        if (originalOnLoad) {
          originalOnLoad.call(this, event);
        }
      };

      this.onerror = function(event) {
        warn('NetworkInterceptor', 'API请求失败:', {
          url: this._url,
          method: this._method
        });

        if (originalOnError) {
          originalOnError.call(this, event);
        }
      };
    }

    return originalSend.apply(this, [body]);
  };
}

/**
 * 拦截Fetch API
 */
function interceptFetch() {
  const originalFetch = window.fetch;

  window.fetch = async function(input, init) {
    const url = typeof input === 'string' ? input : input.url;
    const method = init?.method || 'GET';
    const targetAPI = isTargetAPI(url);

    if (targetAPI) {
      info('NetworkInterceptor', `拦截到目标Fetch请求: ${targetAPI.name}`, {
        url: url,
        method: method
      });

      try {
        const response = await originalFetch(input, init);

        // 克隆响应以便多次读取
        const clonedResponse = response.clone();

        // 异步处理响应
        clonedResponse.text().then(text => {
          try {
            handleApiResponse(url, method, text, targetAPI);
          } catch (err) {
            error('NetworkInterceptor', '处理Fetch响应失败:', err);
          }
        }).catch(err => {
          error('NetworkInterceptor', '读取Fetch响应失败:', err);
        });

        return response;
      } catch (err) {
        warn('NetworkInterceptor', 'Fetch请求失败:', {
          url: url,
          method: method,
          error: err.message
        });
        throw err;
      }
    }

    return originalFetch(input, init);
  };
}

/**
 * 处理API响应
 * @param {string} url - 请求URL
 * @param {string} method - 请求方法
 * @param {string} responseText - 响应文本
 * @param {Object} apiConfig - API配置
 */
function handleApiResponse(url, method, responseText, apiConfig) {
  try {
    const responseData = JSON.parse(responseText);

    info('NetworkInterceptor', `处理API响应: ${apiConfig.name}`, {
      url: url,
      method: method,
      hasData: !!responseData
    });

    // 发送数据到内容脚本
    window.postMessage({
      type: 'DOUYIN_API_DATA',
      response: responseData,
      url: url,
      method: method,
      apiName: apiConfig.name,
      timestamp: Date.now()
    }, '*');

  } catch (err) {
    error('NetworkInterceptor', '解析API响应失败:', err);
    warn('NetworkInterceptor', '原始响应文本:', responseText.substring(0, 200));
  }
}

/**
 * 初始化注入脚本
 */
function initializeInjectScript() {
  info('InjectScript', '开始初始化注入脚本');

  try {
    // 初始化网络拦截器
    initializeNetworkInterceptor();

    // 设置全局消息处理器
    setupGlobalMessageHandler();

    info('InjectScript', '注入脚本初始化完成');
  } catch (err) {
    error('InjectScript', '注入脚本初始化失败:', err);
  }
}

/**
 * 设置全局消息处理器
 */
function setupGlobalMessageHandler() {
  // 监听来自内容脚本的消息（如果需要）
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;

    if (event.data && event.data.type === 'INJECT_COMMAND') {
      handleInjectCommand(event.data);
    }
  });
}

/**
 * 处理注入命令
 */
function handleInjectCommand(data) {
  info('InjectScript', '收到注入命令:', data.command);

  switch (data.command) {
    case 'GET_STATS':
      sendStatsToContent();
      break;
    case 'RESET_INTERCEPTOR':
      resetNetworkInterceptor();
      break;
    default:
      warn('InjectScript', '未知的注入命令:', data.command);
  }
}

/**
 * 发送统计信息到内容脚本
 */
function sendStatsToContent() {
  const stats = {
    type: 'INJECT_STATS',
    data: {
      timestamp: Date.now(),
      url: window.location.href,
      userAgent: navigator.userAgent
    }
  };

  window.postMessage(stats, '*');
}

/**
 * 重置网络拦截器
 */
function resetNetworkInterceptor() {
  info('InjectScript', '重置网络拦截器');
  // 这里可以添加重置逻辑
}

// 立即初始化 - 在页面最早期注入
info('InjectScript', '注入脚本开始执行，当前时间:', new Date().toISOString());
info('InjectScript', '页面状态:', document.readyState);
initializeInjectScript();
