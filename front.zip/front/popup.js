/**
 * Popup页面脚本
 * 负责用户登录、设置管理和统计显示
 */

// 全局变量
let currentUser = null;
let isLoading = false;

/**
 * 日志工具函数
 */
function logInfo(message, data = null) {
  console.log(`[聚抖自媒体大师-Popup] ${message}`, data || '');
}

function logError(message, error = null) {
  console.error(`[聚抖自媒体大师-Popup] ${message}`, error || '');
}

/**
 * DOM加载完成后初始化
 */
document.addEventListener('DOMContentLoaded', async () => {
  logInfo('Popup页面初始化开始');
  
  try {
    // 初始化UI事件监听器
    initializeEventListeners();
    
    // 加载用户状态
    await loadUserStatus();
    
    // 加载统计数据
    await loadStatistics();
    
    logInfo('Popup页面初始化完成');
  } catch (error) {
    logError('Popup页面初始化失败:', error);
  }
});

/**
 * 初始化事件监听器
 */
function initializeEventListeners() {
  // 登录表单
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }
  
  // 退出登录按钮
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', handleLogout);
  }
  
  // 刷新积分按钮
  const refreshCreditsBtn = document.getElementById('refresh-credits-btn');
  if (refreshCreditsBtn) {
    refreshCreditsBtn.addEventListener('click', refreshUserInfo);
  }
  
  // 刷新积分记录按钮
  const refreshCreditsHistoryBtn = document.getElementById('refresh-credits-history-btn');
  if (refreshCreditsHistoryBtn) {
    refreshCreditsHistoryBtn.addEventListener('click', loadCreditsHistory);
  }
  
}

/**
 * 加载用户状态
 */
async function loadUserStatus() {
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'GET_USER_AUTH'
    });
    
    logInfo('获取用户认证状态:', response);
    
    if (response && response.success && response.data.token) {
      currentUser = response.data;
      logInfo('用户已登录，显示用户信息:', { userId: currentUser.userId, credits: currentUser.credits });
      showUserInfo(response.data);
    } else {
      logInfo('用户未登录，显示登录表单');
      showLoginForm();
    }
  } catch (error) {
    logError('加载用户状态失败:', error);
    showLoginForm();
  }
}

/**
 * 显示登录表单
 */
function showLoginForm() {
  const loginSection = document.getElementById('login-section');
  const userInfo = document.getElementById('user-info');
  const statsSection = document.getElementById('stats-section');
  const creditsHistorySection = document.getElementById('credits-history-section');
  
  if (loginSection && userInfo) {
    loginSection.style.display = 'block';
    userInfo.style.display = 'none';
  }
  
  // 隐藏登录后才显示的内容
  if (statsSection) {
    statsSection.style.display = 'none';
  }
  
  if (creditsHistorySection) {
    creditsHistorySection.style.display = 'none';
  }
}

/**
 * 显示用户信息
 */
function showUserInfo(userData) {
  const loginSection = document.getElementById('login-section');
  const userInfo = document.getElementById('user-info');
  const statsSection = document.getElementById('stats-section');
  const creditsHistorySection = document.getElementById('credits-history-section');
  
  if (loginSection && userInfo) {
    loginSection.style.display = 'none';
    userInfo.style.display = 'flex';
  }
  
  // 显示登录后的内容
  if (statsSection) {
    statsSection.style.display = 'block';
  }
  
  if (creditsHistorySection) {
    creditsHistorySection.style.display = 'block';
  }
  
  // 更新用户信息显示
  const usernameElement = document.getElementById('current-username');
  const creditsElement = document.getElementById('credits-amount');
  const membershipStatusEl = document.getElementById('membership-status');
  const membershipTextEl = document.getElementById('membership-text');
  const creditsBreakdownEl = document.getElementById('credits-breakdown');
  const creditsDetailTextEl = document.getElementById('credits-detail-text');
  
  if (usernameElement) {
    usernameElement.textContent = userData.userId || '未知用户';
  }
  
  if (creditsElement) {
    // 修复积分显示：优先使用profile中的total_credits，然后是userData.credits
    const totalCredits = (userData.profile && userData.profile.total_credits) || userData.credits || 0;
    creditsElement.textContent = totalCredits;
  }

  // 显示会员状态
  const membership = userData.membership;
  if (membership && membership.Status === 'active') {
    if (membershipStatusEl) {
      membershipStatusEl.style.display = 'flex';
      if (membershipTextEl) {
        const type = membership.Type || '会员';
        const endDate = membership.EndDate ? new Date(membership.EndDate).toLocaleDateString() : '';
        membershipTextEl.textContent = `${type} · 有效期至 ${endDate}`;
      }
    }
  } else {
    if (membershipStatusEl) {
      membershipStatusEl.style.display = 'none';
    }
  }

  // 显示积分细分（从profile中获取）
  const profile = userData.profile;
  if (profile && (profile.checkin_credits || profile.purchase_credits || profile.membership_credits)) {
    if (creditsBreakdownEl) creditsBreakdownEl.style.display = 'flex';
    if (creditsDetailTextEl) {
      const checkin = profile.checkin_credits || 0;
      const purchase = profile.purchase_credits || 0;
      const memberCredits = profile.membership_credits || 0;
      creditsDetailTextEl.textContent = `签到 ${checkin} · 购买 ${purchase} · 会员 ${memberCredits}`;
    }
  } else {
    if (creditsBreakdownEl) creditsBreakdownEl.style.display = 'none';
  }
  
  // 加载积分记录
  loadCreditsHistory();
}

/**
 * 刷新用户信息
 */
async function refreshUserInfo() {
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'GET_USER_AUTH'
    });
    
    if (response && response.success && response.data.token) {
      // 调用后端API获取最新用户信息
      const meResponse = await chrome.runtime.sendMessage({
        type: 'GET_USER_PROFILE'
      });
      
      if (meResponse && meResponse.success) {
        const freshProfile = meResponse.data;
        const existingUserData = response.data; // 获取当前完整的用户信息

        // 只更新积分，保留其他信息（如会员状态）
        const updatedUserData = {
          ...existingUserData,
          credits: freshProfile.TotalCredits || existingUserData.credits || 0,
          profile: {
            ...existingUserData.profile,
            TotalCredits: freshProfile.TotalCredits || (existingUserData.profile ? existingUserData.profile.TotalCredits : 0)
          }
        };
        
        currentUser = updatedUserData;
        showUserInfo(currentUser);
      }
    }
  } catch (error) {
    logError('刷新用户信息失败:', error);
  }
}

/**
 * 处理登录
 */
async function handleLogin(event) {
  event.preventDefault();
  
  if (isLoading) return;
  
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  
  if (!username || !password) {
    showNotification('请填写用户名和密码', 'error');
    return;
  }
  
  setLoginLoading(true);
  
  try {
    // 尝试直接在popup中发送请求（绕过Service Worker的网络限制）
    let response;
    
    try {
      logInfo('尝试通过Service Worker登录...');
      response = await chrome.runtime.sendMessage({
        type: 'LOGIN',
        credentials: {
          username: username,
          password: password
        }
      });
    } catch (serviceWorkerError) {
      logError('Service Worker登录失败，尝试直接登录:', serviceWorkerError);
      
      // 备用方案：直接在popup中发送请求
      const directResponse = await fetch('http://localhost:8080/api/v1/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          phone: username,
          password: password
        })
      });
      
      const data = await directResponse.json();
      
      if (directResponse.ok && data.token) {
        // 手动保存到Service Worker
        await chrome.runtime.sendMessage({
          type: 'SAVE_AUTH',
          authData: {
            token: data.token,
            userId: data.profile?.Username || data.profile?.Phone || username,
            credits: data.profile?.total_credits || 0,
            userID: data.profile?.ID || null,
            membership: data.profile?.membership || null,
            profile: data.profile
          }
        });
        
        response = {
          success: true,
          data: {
            token: data.token,
            userId: data.profile?.Username || data.profile?.Phone || username,
            credits: data.profile?.total_credits || 0,
            membership: data.profile?.membership || null,
            profile: data.profile
          }
        };
      } else {
        response = {
          success: false,
          error: data.error || '登录失败'
        };
      }
    }
    
    if (response && response.success) {
      currentUser = response.data;
      showUserInfo(currentUser);
      showNotification('登录成功！', 'success');
      
      // 清空表单
      document.getElementById('login-form').reset();
      
      // 刷新统计数据
      await loadStatistics();
    } else {
      showNotification(response?.error || '登录失败', 'error');
    }
  } catch (error) {
    logError('登录失败:', error);
    showNotification('登录失败: ' + error.message, 'error');
  } finally {
    setLoginLoading(false);
  }
}

/**
 * 处理退出登录
 */
async function handleLogout() {
  if (isLoading) return;
  
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'LOGOUT'
    });
    
    if (response && response.success) {
      currentUser = null;
      showLoginForm();
      showNotification('已成功退出登录', 'success');
      
      // 重置统计数据
      resetStatistics();
    } else {
      showNotification('退出登录失败', 'error');
    }
  } catch (error) {
    logError('退出登录失败:', error);
    showNotification('退出登录失败: ' + error.message, 'error');
  }
}

/**
 * 设置登录按钮的加载状态
 */
function setLoginLoading(loading) {
  isLoading = loading;
  const loginBtn = document.getElementById('login-btn');
  
  if (loginBtn) {
    if (loading) {
      loginBtn.classList.add('loading');
      loginBtn.disabled = true;
    } else {
      loginBtn.classList.remove('loading');
      loginBtn.disabled = false;
    }
  }
}


/**
 * 加载积分记录
 */
async function loadCreditsHistory() {
  try {
    const creditsHistoryList = document.getElementById('credits-history-list');
    if (!creditsHistoryList) return;
    
    creditsHistoryList.innerHTML = '<div class="loading-message">加载中...</div>';
    
    const response = await chrome.runtime.sendMessage({
      type: 'GET_CREDITS_HISTORY'
    });
    
    if (response && response.success && response.data) {
      const history = response.data;
      
      if (history.length === 0) {
        creditsHistoryList.innerHTML = '<div class="no-data-message">暂无积分记录</div>';
        return;
      }
      
      let historyHtml = '';
      history.slice(0, 10).forEach(record => { // 只显示最近10条
        const date = new Date(record.CreatedAt).toLocaleDateString();
        const time = new Date(record.CreatedAt).toLocaleTimeString();
        const amount = record.amount > 0 ? `+${record.amount}` : record.amount;
        const amountClass = record.amount > 0 ? 'credit-positive' : 'credit-negative';
        
        historyHtml += `
          <div class="credit-record">
            <div class="credit-info">
              <div class="credit-description">${record.description || '积分变动'}</div>
              <div class="credit-datetime">${date} ${time}</div>
            </div>
            <div class="credit-amount ${amountClass}">${amount}</div>
          </div>
        `;
      });
      
      creditsHistoryList.innerHTML = historyHtml;
    } else {
      creditsHistoryList.innerHTML = '<div class="error-message">加载失败，请重试</div>';
    }
  } catch (error) {
    logError('加载积分记录失败:', error);
    const creditsHistoryList = document.getElementById('credits-history-list');
    if (creditsHistoryList) {
      creditsHistoryList.innerHTML = '<div class="error-message">加载失败，请重试</div>';
    }
  }
}

/**
 * 加载统计数据
 */
async function loadStatistics() {
  try {
    // 从本地存储获取统计数据
    const stats = await chrome.storage.local.get([
      'results_single_text',
      'results_batch_text',
      'results_profile_analysis'
    ]);
    
    let totalExtractions = 0;
    let totalAnalyses = 0;
    let creditsUsed = 0;
    
    // 计算文案提取次数
    if (stats.results_single_text) {
      totalExtractions += stats.results_single_text.length;
    }
    
    if (stats.results_batch_text) {
      totalExtractions += stats.results_batch_text.length;
      // 计算积分消耗
      stats.results_batch_text.forEach(item => {
        if (item.creditsUsed) {
          creditsUsed += item.creditsUsed;
        }
      });
    }
    
    // 计算分析次数
    if (stats.results_profile_analysis) {
      totalAnalyses = stats.results_profile_analysis.length;
    }
    
    // 更新显示
    updateStatistics({
      totalExtractions,
      totalAnalyses,
      creditsUsed
    });
  } catch (error) {
    logError('加载统计数据失败:', error);
  }
}

/**
 * 更新统计数据显示
 */
function updateStatistics(stats) {
  const totalExtractionsElement = document.getElementById('total-extractions');
  const totalAnalysesElement = document.getElementById('total-analyses');
  const creditsUsedElement = document.getElementById('credits-used');
  
  if (totalExtractionsElement) {
    totalExtractionsElement.textContent = stats.totalExtractions || 0;
  }
  
  if (totalAnalysesElement) {
    totalAnalysesElement.textContent = stats.totalAnalyses || 0;
  }
  
  if (creditsUsedElement) {
    creditsUsedElement.textContent = stats.creditsUsed || 0;
  }
}

/**
 * 重置统计数据
 */
function resetStatistics() {
  updateStatistics({
    totalExtractions: 0,
    totalAnalyses: 0,
    creditsUsed: 0
  });
}

/**
 * 显示通知
 */
function showNotification(message, type = 'info') {
  const notification = document.getElementById('notification');
  const notificationText = notification.querySelector('.notification-text');
  const notificationIcon = notification.querySelector('.notification-icon');
  
  if (!notification || !notificationText || !notificationIcon) {
    return;
  }
  
  // 设置消息内容
  notificationText.textContent = message;
  
  // 设置图标和样式
  notification.className = 'notification ' + type;
  
  switch (type) {
    case 'success':
      notificationIcon.textContent = 'check_circle';
      break;
    case 'error':
      notificationIcon.textContent = 'error';
      break;
    case 'warning':
      notificationIcon.textContent = 'warning';
      break;
    default:
      notificationIcon.textContent = 'info';
  }
  
  // 显示通知
  notification.style.display = 'block';
  
  // 3秒后自动隐藏
  setTimeout(() => {
    notification.style.display = 'none';
  }, 3000);
}


// 监听来自背景脚本的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'UPDATE_USER_CREDITS') {
    if (currentUser) {
      currentUser.credits = message.credits;
      const creditsElement = document.getElementById('credits-amount');
      if (creditsElement) {
        creditsElement.textContent = message.credits;
      }
    }
  }
});
