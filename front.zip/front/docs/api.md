# 获取单个视频文案api
## curl
``` curl -X POST 'https://api.coze.cn/v1/workflow/run' \
-H "Authorization: Bearer cztei_qTzgGKUaBd5cWqnTujIbDzObapBesqhrMfFbPqP3MODqvLzULfKGtOgDW9tJINA94" \
-H "Content-Type: application/json" \
-d '{
  "workflow_id": "7523553842999607311",
  "parameters": {
    "input": "https://www.douyin.com/user/MS4wLjABAAAATWHCpP_LB9LwhWFjdVp2M15sXjVgZU3iCwJHRQPx2nMAN87MHHbfFJBpAWC8qJSV?from_tab_name=main&modal_id=7547641930486713641"
  },
  "is_async": false
}'

```

## 返回：
```
{"code":0,"data":"{\"content\":\"这里是文案的内容…………。\",\"cover_url\":\"https://p3-sign.douyinpic.com/tos-cn-i-dy/0b99854113524a4195f5c2afabe43f9e~c5_300x400.webp?lk3s=138a59ce&x-expires=1758715200&x-signature=ITwS7U%2F9b4TQ27h9RQES0PXERqs%3D&from=327834062_large&s=PackSourceEnum_AWEME_DETAIL&se=false&sc=cover&biz_tag=aweme_video&l=20250910204828443FB968E8904D155F27\",\"downurl\":\"https://aweme.snssdk.com/aweme/v1/play/?video_id=v0d00fg10000d2v9mv7og65v3fuecgn0&line=0&ratio=1080&media_type=4&vr_type=0&improve_bitrate=0&is_play_url=1&is_support_h265=0&source=PackSourceEnum_PUBLISH\",\"title\":\"happy every day #脱口秀#二狗脱口秀#观众搭茬#每日一笑\"}","debug_url":"https://www.coze.cn/work_flow?execute_id=7548441556433551403&space_id=7468856044970754057&workflow_id=7523553842999607311&execute_mode=2","msg":"Success","usage":{"input_count":0,"output_count":0,"token_count":0}}
```



# 主页账号分析
## 主页信息获取：拦截post 请求，从中提取 主页名称，粉丝数、获赞数和关注数。
https://www.douyin.com/aweme/v1/web/user/profile/other/?device_platform=webapp&aid=6383&channel=channel_pc_web&publish_video_strategy_type=2&source=channel_pc_web&sec_user_id=MS4wLjABAAAAJuoFbjxDr_kjVYLy-7jRb9xNjP6AatXyI7gLRV3QLJw&personal_center_strategy=1&profile_other_record_enable=1&land_to=1&update_version_code=170400&pc_client_type=1&pc_libra_divert=Mac&support_h265=1&support_dash=1&cpu_core_num=10&version_code=170400&version_name=17.4.0&cookie_enabled=true&screen_width=2560&screen_height=1440&browser_language=zh-CN&browser_platform=MacIntel&browser_name=Edge&browser_version=139.0.0.0&browser_online=true&engine_name=Blink&engine_version=139.0.0.0&os_name=Mac+OS&os_version=10.15.7&device_memory=8&platform=PC&downlink=10&effective_type=4g&round_trip_time=100&webid=7494269215601395250&uifid=3d19da18631c82d4defe04a0ec2c3c4673f37bfeb7cebeed4cb99b3c023f108fac09fba222a510a7f8286d8b09827d8e6008a75dcf0db1b76d0c8f9597410b41e65e8a4c9da4043bed1d6250d9367c7a77627bc742403b1efd05c0d8f7f69bc7796c11ced7cc31a6c287c66003485e11c4c10ca38e83c9140f6b761d77ae8ad62a99aa04c3082493e78390aac34a1874c47ac59b57dc960fc5d96b4d514085c2&verifyFp=verify_mf19zybp_sg6CH5LB_uio6_4dOk_8FWj_ufh4JmdvoQvF&fp=verify_mf19zybp_sg6CH5LB_uio6_4dOk_8FWj_ufh4JmdvoQvF&msToken=g_fRT3Q67ZO-3ISo4wFdSZym0-XU2nwoi198_jsCOaHbujx_mKDEcCZa1nRDVM4Ox-JFWEBZiQchwQGivfGlViq8xOYSyQAnU-bSfLf3-VScsQRdX34rwLL9d6VANlGCW4-fgOiLy4fv5A-lpOG_czXSa9NfmRaiDPPiPBYkAZ9M24sWvqpS3qM%3D&a_bogus=x64RgFU7DxmbcdKbucJ%2F9VBU8ZgMrT8ygqiQS7oTCPuWcXtbwbPtLNCuaxz15uQi6mB0iKIHLEzlbDVc0sXiZqnkumpkSYkSn0A9V7mL01qpP0k0DNDzCz0zFX0e8RGqeQ5UEA63ZUGy1Vn-wHQL%2FdByyASC5muhKZx6kMzSx9ag1%2FuIoZMwiZ0gefnq5-%2F2PW1THj%3D%3D


拦截数据数据：
{
    
    "user": {
       
        "following_count": 108,
        
        "nickname": "寅山",

        "signature": "V:6666378\n灾难艺术家\n海晏北路知名书法爱好者",

        "total_favorited": 19388399,

        "user_age": 28,

}

video_data : 使用 inject.js 拦截的数据。就是再 content.js中的 interceptedData.


## 主页分析 curl
```
curl -X POST 'https://api.coze.cn/v1/workflow/run' \
-H "Authorization: Bearer sat_fNtvRmUkaSfs8EBzBQWyC4UfzZd7DftlzZJRUYs70scDARwjQEcI7TpoyOOVIRRc" \
-H "Content-Type: application/json" \
-d '{
  "workflow_id": "7523977048177279027",
  "parameters": {
    "author_info": "",
    "video_data": ""
  }
}'
```

```
返回数据：
{"detail":{"logid":"20250912110223DADFB13B38CFF3AC714C"},"code":0,"msg":"","data":"{\"content_type\":1,\"data\":\"您好！非常理解您希望通过对标分析提升自身抖音账号竞争力的需求。\\n\\n不过，您提供的“用户视频数据”和“用户账号数据”均为“null”，这意味着我没有收到任何关于您想要分析的**具体对标抖音账户的信息**（例如：该账户的名称、ID、主页链接，或者您对该账户的简单描述，如“一个教化妆的账号”、“一个搞笑剧情号”等）。\\n\\n**没有具体的对标账户信息，我无法进行任何有针对性的深度分析。**\\n\\n**为了能够帮助您完成这份对标账户深度分析报告，请您提供以下至少一项关键信息：**\\n\\n1.  **对标抖音账户的准确名称或ID**：这是最直接有效的方式，我可以通过名称或ID搜索到该账户。\\n2.  **对标抖音账户的主页链接**：如果您方便复制链接，那将是最快的。\\n3.  **对该对标账户的详细描述**：例如，它的主要内容领域（美妆、美食、科技、教育、剧情、Vlog等）、博主的大致风格、您认为它成功的地方、您为什么想对标它等等。描述越详细，我越有可能帮您缩小范围或给出更具普适性的分析框架（但精准度会下降）。\\n\\n**在您提供上述信息后，我将立即按照您要求的核心维度（账户定位与内容策略、运营数据与互动表现、商业变现模式、差异化优势与创新点、对您的启发与建议）为您生成一份详细的分析报告。**\\n\\n期待您的回复！\",\"original_result\":null,\"type_for_model\":2}","debug_url":"https://www.coze.cn/work_flow?execute_id=7549032703632539657&space_id=7468856044970754057&workflow_id=7523977048177279027&execute_mode=2","usage":{"token_count":1098,"output_count":350,"input_count":748}}
```

