# Background.js 功能说明文档

## 概述

`background.js` 是聚抖自媒体大师浏览器插件的后台服务脚本，作为 Chrome Extension 的 Service Worker 运行。

**简单来说：这个文件就是一个消息中转站和数据存储管理器。**

## 核心功能

### 1. 消息处理中心 📨
- **作用**：接收来自前端页面（content.js、popup.js）的消息请求
- **处理的消息类型**：
  - `INTERCEPTED_DATA` - 保存拦截到的网络数据
  - `EXTRACT_SINGLE_TEXT` - 提取单个视频文案
  - `EXTRACT_ALL_TEXTS` - 批量提取视频文案
  - `ANALYZE_PROFILE` - 分析用户主页
  - `LOGIN/LOGOUT` - 用户登录登出
  - `CLEAR_STORAGE` - 清理存储数据

### 2. 数据存储管理 💾
- **拦截数据存储**：保存从抖音页面拦截到的API响应数据
- **结果数据存储**：保存文案提取和分析的结果
- **用户信息存储**：保存登录状态、积分等用户数据
- **自动清理机制**：定期清理过期数据，防止存储空间不足

### 3. API调用服务 🌐
- **单个文案提取**：调用 Coze API 提取视频文案
- **批量处理**：处理多个视频的批量操作
- **用户认证**：处理登录、退出等认证相关操作

## 文件结构分析

### 全局变量
```javascript
// 服务器配置
serverConfig = {
  baseUrl: 'https://api.example.com',
  apiKey: null,
  isAuthenticated: false
}

// 用户认证信息
userAuth = {
  token: null,
  userId: null,
  credits: 0
}
```

### 主要函数分类

#### 🔧 初始化函数
- `initializeStorage()` - 初始化存储结构
- `loadConfiguration()` - 加载配置信息
- `startPeriodicCleanup()` - 启动定期清理任务

#### 📨 消息处理函数
- `handleMessage()` - 消息分发中心
- `handleInterceptedData()` - 处理拦截数据
- `handleExtractSingleText()` - 处理单个文案提取
- `handleExtractAllTexts()` - 处理批量文案提取
- `handleAnalyzeProfile()` - 处理主页分析
- `handleLogin()/handleLogout()` - 处理用户认证

#### 🗄️ 存储管理函数
- `cleanupStorage()` - 常规存储清理
- `forceCleanupStorage()` - 强制清理（配额超限时）
- `saveExtractResult()` - 保存提取结果
- `updateUserAuth()` - 更新用户认证信息

#### 🌐 API调用函数
- `callServerAPI()` - 通用API调用封装
- `simulateAPICall()` - 模拟API响应（开发用）

## 问题分析

### 当前存在的复杂度问题：

1. **存储管理过于复杂**
   - 多层存储清理逻辑
   - 复杂的配额检查机制
   - 过度的数据压缩处理

2. **功能职责混乱**
   - 既处理消息又管理存储
   - 既调用API又处理认证
   - 既做数据压缩又做定期清理

3. **代码冗余**
   - 多个清理函数功能重复
   - 过度的错误处理和重试机制
   - 不必要的数据压缩逻辑

## 简化建议

### 应该保留的核心功能：
1. **消息监听和分发** - 这是必须的
2. **基本的数据存储** - 保存拦截数据和结果
3. **API调用封装** - 调用外部服务
4. **简单的存储清理** - 防止数据过多

### 可以删除的复杂功能：
1. **复杂的存储配额管理** - Chrome会自动管理
2. **多层数据压缩** - 没必要
3. **定期清理任务** - 可以改为按需清理
4. **过度的错误恢复机制** - 简化即可

## 建议的简化版本

```javascript
// 简化后的核心结构
1. 消息监听器 - 接收和分发消息
2. 数据存储函数 - 简单的存储和读取
3. API调用函数 - 封装外部API调用
4. 基础工具函数 - 日志、配置等
```

## 总结

**这个文件本质上就是一个"服务员"**：
- 接收前端的请求（消息监听）
- 调用外部服务获取数据（API调用）
- 把数据存储起来（数据管理）
- 把结果返回给前端（消息响应）

目前的问题是这个"服务员"被训练得过于复杂，做了很多不必要的事情。应该简化为只做核心的4件事就够了。
